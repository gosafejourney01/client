import { combineReducers } from 'redux';

import auth from './reducers/auth';
import property from './reducers/property';
import room from './reducers/room';
import booking from './reducers/booking';

export default combineReducers({
  auth, property, room, booking,
});
