import {
  START_LOADING, END_LOADING, FETCH_BOOKINGS, FETCH_BOOKING, CANCEL_BOOKING,
} from '../../constants/actionTypes';

const bookingReducer = (state = { isLoading: true, bookingData: {}, allBookings: [] }, action) => {
  switch (action.type) {
    case START_LOADING:
      return { ...state, isLoading: true };
    case END_LOADING:
      return { ...state, isLoading: false };
    case FETCH_BOOKING:
    case CANCEL_BOOKING:
      return { ...state, bookingData: action.payload };
    case FETCH_BOOKINGS:
      return { ...state, allBookings: action.payload };

    default:
      return state;
  }
};

export default bookingReducer;
