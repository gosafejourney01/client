import { combineReducers } from 'redux';

import auth from './auth';
import property from './property';
import room from './room';
import booking from './booking';

export default combineReducers({
  auth, property, room, booking,
});
