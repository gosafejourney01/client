import { AUTH, UPDATE_AUTH, LOGOUT } from '../../constants/actionTypes';

const updateStorage = (data) => {
  const existingData = JSON.parse(localStorage.getItem('profile')) || {};
  const updatedData = { ...existingData, result: data };
  localStorage.setItem('profile', JSON.stringify(updatedData));
};

const authReducer = (state = { authData: null }, action) => {
  switch (action.type) {
    case AUTH:
      localStorage.setItem('profile', JSON.stringify({ ...action?.data }));
      return { ...state, authData: action?.data.result };
    case UPDATE_AUTH:
      updateStorage(action?.data);
      return { ...state, authData: action?.data.result };

    case LOGOUT:
      localStorage.clear();
      return { ...state, authData: null };

    default:
      return state;
  }
};

export default authReducer;
