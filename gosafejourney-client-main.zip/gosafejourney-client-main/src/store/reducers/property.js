import {
  START_LOADING, END_LOADING, FETCH_PROPERTIES,
} from '../../constants/actionTypes';

const propertyReducer = (state = { isLoading: true, propertyData: [] }, action) => {
  switch (action.type) {
    case START_LOADING:
      return { ...state, isLoading: true };
    case END_LOADING:
      return { ...state, isLoading: false };
    case FETCH_PROPERTIES:
      return { ...state, propertyData: action.payload };
    default:
      return state;
  }
};

export default propertyReducer;
