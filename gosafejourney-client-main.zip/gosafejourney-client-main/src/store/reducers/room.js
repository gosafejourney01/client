import {
  START_LOADING, END_LOADING, FETCH_ROOMS,
} from '../../constants/actionTypes';

const roomReducer = (state = { isLoading: true, roomData: [] }, action) => {
  switch (action.type) {
    case START_LOADING:
      return { ...state, isLoading: true };
    case END_LOADING:
      return { ...state, isLoading: false };
    case FETCH_ROOMS:
      return { ...state, roomData: action.payload };

    default:
      return state;
  }
};

export default roomReducer;
