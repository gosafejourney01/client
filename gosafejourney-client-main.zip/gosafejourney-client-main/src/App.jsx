import './App.scss';
import React, { useState, useLayoutEffect } from 'react';
import { Toaster } from 'react-hot-toast';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Footer from './components/Footer/Footer';
import Header from './components/Header/Header';
import Home from './pages/Home/Home';
import PropertyDetails from './pages/PropertyDetails/PropertyDetails';
import BookingDetails from './pages/BookingDetails/BookingDetails';
import PropertySearch from './pages/PropertySearch/PropertySearch';
import BookingReview from './pages/BookingReview/BookingReview';
import Profile from './pages/Profile/Profile';
import MyBookings from './pages/MyBookings/MyBookings';
import PrivateRoute from './PrivateRoute';
import ResetPassword from './pages/ResetPassword/ResetPassword';

function App() {
  const initialState = {
    stayTypes: [],
    location: 'Delhi',
    checkInDate: new Date(),
    checkOutDate: new Date(new Date().getTime() + 24 * 60 * 60 * 1000),
    adults: 1,
    kids: 0,
    pricingRange: null,
  };
  const [formData, setFormData] = useState(initialState);
  const [currentProperty, setCurrentProperty] = useState();
  const [userAddress, setUserAddress] = useState(null);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleCheckInCheckOutChange = (checkInDate, checkOutDate) => {
    setFormData({ ...formData, checkInDate, checkOutDate });
  };

  const handlePricingChange = (e) => {
    setFormData({
      ...formData,
      amenities: {
        ...formData.pricingRange,
        [e.target.name]: e.target.checked,
      },
    });
  };

  const handleStayTypeChange = (stayType) => {
    if (formData.stayTypes.some((item) => stayType === item)) {
      setFormData({
        ...formData,
        stayTypes: formData.stayTypes.filter((item) => item !== stayType),
      });
    } else {
      setFormData({
        ...formData,
        stayTypes: [...formData.stayTypes, stayType],
      });
    }
  };

  useLayoutEffect(() => {
    navigator.geolocation.getCurrentPosition((position) => {
      const { latitude, longitude } = position.coords;

      fetch(`https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=AIzaSyBqRIMbYtfo6i0eNVbQ6myB1MNiA6_DVSw`)
        .then((response) => {
          response.json();
        })
        .then((data) => {
          setUserAddress(data?.results[1].formatted_address);
          setFormData({ ...formData, location: userAddress });
        });
    });
  }, []);

  return (
    <Router>
      <div className="App">
        <div className="App__header">
          <Header />
          <div className="App__content">
            <Routes>
              <Route
                exact
                path="/"
                element={(
                  <Home
                    formData={formData}
                    setFormData={setFormData}
                    handleChange={handleChange}
                    handleCheckInCheckOutChange={handleCheckInCheckOutChange}
                    handleStayTypeChange={handleStayTypeChange}
                  />
                )}
              />
              <Route
                exact
                path="/property-search"
                element={(
                  <PropertySearch
                    setCurrentProperty={setCurrentProperty}
                    formData={formData}
                    setFormData={setFormData}
                    handleChange={handleChange}
                    handleCheckInCheckOutChange={handleCheckInCheckOutChange}
                    handleStayTypeChange={handleStayTypeChange}
                    handlePricingChange={handlePricingChange}
                  />
                )}
              />
              <Route
                exact
                path="/property-details"
                element={(
                  <PropertyDetails
                    formData={formData}
                    currentProperty={currentProperty}
                    setFormData={setFormData}
                    handleChange={handleChange}
                    handleCheckInCheckOutChange={handleCheckInCheckOutChange}
                    handlePricingChange={handlePricingChange}
                  />
                )}
              />
              <Route
                exact
                path="/booking"
                element={<BookingReview formData={formData} />}
              />
              <Route
                exact
                path="/booking-details"
                element={<BookingDetails />}
              />
              <Route exact path="/profile" element={<Profile />} />
              <Route exact path="/mybooking" element={<MyBookings />} />
              <Route exact path="/reset-password" element={<PrivateRoute />}>
                <Route
                  exact
                  path="/reset-password"
                  element={<ResetPassword />}
                />
              </Route>
            </Routes>
          </div>
        </div>
        <Footer />
        <Toaster />
      </div>
    </Router>
  );
}

export default App;
