/* eslint-disable */
import React, { useState } from "react";
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { getBooking } from '../../actions/booking';
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
// import Tooltip from '@mui/material/Tooltip';
// import ClickAwayListener from '@mui/material/ClickAwayListener';
// import { IconButton } from '@mui/material';
import "./PriceBreakup.scss";
import * as api from '../../api/index.js';
import Tooltip, { TooltipPrimitive } from '@atlaskit/tooltip';
import { styled } from '@mui/material/styles';

const InlineDialog = styled(TooltipPrimitive)`
background: white;
border-radius: 4px;
box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
box-sizing: content-box; /* do not set this to border-box or it will break the overflow handling */
color: #333;
max-height: 300px;
max-width: 300px;
padding: 15px;
`;

function PriceBreakup({
  bookingStatus = "booking",
  amount,
  room,
  night,
  date1,
  date2,
  generateBill,
  formData,
  names,
}) {
  const [open, setOpen] = useState(false);
  const { result } = JSON.parse(localStorage.getItem("profile"));
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const getDate = (date) => {
    const formattedDate = new Date(date).toLocaleDateString(
      {},
      {
        timeZone: "Asia/Kolkata",
        month: "long",
        day: "2-digit",
        year: "numeric",
        weekday: "long",
      }
    );
    const sp = formattedDate.split(" ");
    return sp;
  };
  const handleTooltipClose = () => {
    setOpen(false);
  };
  function loadScript(src) {
    return new Promise((resolve) => {
      const script = document.createElement("script");
      script.src = src;
      script.onload = () => {
        resolve(true);
      };
      script.onerror = () => {
        resolve(false);
      };
      document.body.appendChild(script);
    });
  }

  const handleTooltipOpen = () => {
    setOpen(true);
  };

  async function displayRazorpay() {
    const amount = totalPrice(room?.price * night);
    const res = await loadScript(
      "https://checkout.razorpay.com/v1/checkout.js"
    );

    if (!res) {
      alert("Razorpay SDK failed to load. Are you online?");
      return;
    }

    const data = {
      amount,
      currency: 'INR',
      receipt: 'GoSafeJourney',
      notes: 'GoSafeJourney',
    };

    const resultSuccess = await api.createPayment(data);

    const { id: order_id } = resultSuccess.data;

    const options = {
      key: "rzp_test_yNzD02xyEt05fe",
      amount,
      currency: "INR",
      name: result.fullName,
      order_id: order_id,
      description: "GoSafeJourney Transaction",
      handler: async (response) => {
        const data = {
          paymentId: response.razorpay_payment_id,
          orderId: response.razorpay_order_id,
          signature: response.razorpay_signature,
        };
        const booking = {
          bookingStatus: "active",
          bookingId: resultSuccess.data.id,
          clientId: result._id,
          checkInDate: date1 || "",
          checkOutDate: date2 || "",
          roomId: room?._id,
          noBookedRooms: 1,
          amount,
          formData,
          names,
          ...data,
        }
        /* await api.createBooking(booking).then((res) => {
          toast.success('Booking Successful')
          dispatch(getBooking(res.data._id, () => {navigate("/booking-details")}))
        }).catch((err) => {
          toast.error('Booking Failed')
        }) */
        const bookingResponse = await api.createBooking(booking);
        /* generateBill(setProperty).then(() => {
          console.log('TODO')
        }); */
        dispatch(getBooking(bookingResponse.data._id, () => {navigate("/booking-details")}, 'Booking Created Successfully'));
      },
      prefill: {
        name: result.fullName,
        email: result.email,
        contact: result.phone,
      },
      notes: {
        address: "GoSafeJourney",
      },
      theme: {
        color: "#61dafb",
      },
    };

    const paymentObject = new window.Razorpay(options);
    paymentObject.open();
  }
  const getTax = (val) => {
    const tax = (28 * val) / 100;
    return tax;
  };
  const totalPrice = () => {
    const price = room?.price * night + getTax(room?.price * night);
    return price;
  };

  return (
    <div className="pricebreakup">
      <h3>PRICE BREAK-UP</h3>
      <div className="pricebreakup__divider" />
      <div className="pricebreakup__price">
        <div>
          <h4>{`${night} Night`}</h4>
          <p>Base Price</p>
        </div>
        <h4>{room?.price * night}</h4>
      </div>
      <div className="pricebreakup__gst">
        <div>
          <h4>GST</h4>
          <Tooltip
         position="right"
         component={InlineDialog}
         content="28% GST is apllied"
       >
         {(tooltipProps) => (
           <span {...tooltipProps}>
             <InfoOutlinedIcon />
           </span>
         )}
       </Tooltip>
        </div>
        <h4>{`+ ₹ ${getTax(room?.price * night)}`}</h4>
      </div>
      {/* <div className="pricebreakup__servicefee">
        <div>
          {(bookingStatus === 'completed' || bookingStatus === 'active' || bookingStatus === 'ongoing') && (
            <h4>Taxes & Service Fees</h4>
          )}
          {bookingStatus === 'cancelled' && (
            <h4>Refund Tax</h4>
          )}
          <ClickAwayListener onClickAway={handleTooltipClose}>
            <Tooltip
              PopperProps={{
                disablePortal: true,
              }}
              onClose={handleTooltipClose}
              open={open}
              title={(
                <fragment className="pricebreakup__servicefee__gst">
                  <div className="pricebreakup__servicefee__gst__price">
                    <p>Hotel Gst</p>
                    <p>₹261</p>
                  </div>
                  <div className="pricebreakup__servicefee__gst__price">
                    <p>Service Fees</p>
                    <p>₹261</p>
                  </div>
                </fragment>
             )}
            > */}
      {/* <IconButton onClick={handleTooltipOpen}>
                <InfoOutlinedIcon />
              </IconButton>
            </Tooltip>
          </ClickAwayListener>
        </div>
        <h4>₹522</h4>
      </div> */}
      <div className="pricebreakup__totalamount">
        <div>
          {bookingStatus === "booking" && (
            <h4>Total Amount to be paid</h4>
          )}
          {(bookingStatus === "ongoing" || bookingStatus === "active") && <h4>Paid</h4>}
          {bookingStatus === "cancelled" && <h4>Refund</h4>}
        </div>
        <h4>{`₹ ${totalPrice(room?.price * night)}`}</h4>
      </div>
      {(bookingStatus === "booking" || bookingStatus === "active") && (
         <Tooltip
         position="right"
         component={InlineDialog}
         content={`A refund will be issued if the cancellation is made prior to ${room.propertyId.cancellationDays} days from the check-in date; otherwise, no refund will be provided.`}
       >
         {(tooltipProps) => (
           <span {...tooltipProps}>
             <p className="pricebreakup__cancellation">Cancellation Policy</p>
           </span>
         )}
       </Tooltip>
      )}
      <div className={`pricebreakup__${bookingStatus}`} onClick={bookingStatus === "booking" ? displayRazorpay : null}>
        {bookingStatus === "booking" && <span>Pay</span>}
        {(bookingStatus === "ongoing" || bookingStatus === "active") && <span>Paid</span>}
        {bookingStatus === "cancelled" && <span>Booking is cancelled</span>}
        {bookingStatus === "completed" && <span>Book Again</span>}
      </div>
    </div>
  );
}

export default PriceBreakup;
