import {
  Facebook, Twitter, Instagram,
} from '@mui/icons-material';
import './Footer.scss';
import React from 'react';
import { NavLink } from 'react-router-dom';
import logo from '../../images/logo.png';
// import searchicon from '../../images/searchicon.svg';

function Footer() {
  return (
    <div className="footer">
      <div className="footer__details">
        <div className="footer__detailssocial">
          <div className="footer__logo">
            <NavLink to="/"><img src={logo} alt="logo" /></NavLink>
          </div>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate
            libero et velit interdum, ac aliquet odio mattis.
            Class aptent taciti sociosqu ad litora torquent per conubia nostra,
            per inceptos himenaeos.
          </p>
          <div className="footer__detailssocialicons">
            <div className="footer__socialiconcontainer">
              <Facebook />
            </div>
            <div className="footer__socialiconcontainer">
              <Twitter />
            </div>
            <div className="footer__socialiconcontainer">
              <Instagram />
            </div>
          </div>
        </div>
        {/* <div className="footer__detailspages">
          <h6>Properties</h6>
          <p>Hotels</p>
          <p>Apartments</p>
          <p>Resorts</p>
          <p>Villas</p>
          <p>Cottages</p>
          <p>Serviced Apartments</p>
          <p>Guest House</p>
          <p>Hostels</p>
          <p>Motels</p>
          <p>Campsite</p>
          <p>Home Stay</p>
          <p>Luxory Tents</p>
        </div> */}
        <div className="footer__detailspages">
          <h6>Quick Links</h6>
          <p>About Us</p>
          <p>Need Help?</p>
          <p>Terms and Conditions</p>
          <p>Privacy Policy</p>
          <a
            href={process.env.REACT_APP_PARTNER_URL}
            target="_blank"
            rel="noopener noreferrer"
          >
            <p>List Your Property</p>
          </a>
          <p>FAQ</p>
        </div>
        {/* <div className="footer_email">
          <h6>Save time, save money!</h6>
          <p>Sign up and we will send the best deals to you</p>
          <div className="footer__search">
            <input placeholder="enter your email" />
            <div className="footer__searchicon">
              <img src={searchicon} alt="searchicon" />
            </div>
          </div>
        </div> */}
      </div>
    </div>
  );
}

export default Footer;
