/* eslint-disable */
import React, { useState } from 'react';
import './BookingReviewSummary.scss';
// import hotel from '../../../images/hotel.png';
import RoomDetailsModal from '../../RoomDetailsModal/RoomDetailsModal';
// import { useEffect } from 'react';
import logo from '../../../images/logodark.svg';
import Tooltip, { TooltipPrimitive } from '@atlaskit/tooltip';
import { styled } from '@mui/material/styles';

function BookingReviewSummary({ currentProperty, formData, room, night, bill, price }) {
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const getDate = (date) => {
    const formattedDate = new Date(date).toLocaleDateString({}, { timeZone: "UTC", month: "long", day: "2-digit", year: "numeric", weekday: "long" });
    const sp = formattedDate.split(' ');
    return sp;
  }
  // console.log(Object.keys(bill).length);

  const getTax = (val) => {
    const tax = (28 * val) / 100;
    return tax;
  };

  const InlineDialog = styled(TooltipPrimitive)`
  background: white;
  border-radius: 4px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
  box-sizing: content-box; /* do not set this to border-box or it will break the overflow handling */
  color: #333;
  max-height: 300px;
  max-width: 300px;
  padding: 15px;
  `;

  return (
    <div className="bookingReviewSummary">
      <h3>Hotel Information</h3>
      <div className="bookingReviewSummary__divider" />
      <div className="bookingReviewSummary__propertyname">
        <div className="propertyname__content">
          <h2>{currentProperty?.propertyName}</h2>
          <p>{`${currentProperty?.streetAddress}, ${currentProperty?.address}, ${currentProperty?.pincode}, ${currentProperty?.city}, India`}</p>
          <div className="property__type">
            <p>Hotel Stay</p>
          </div>
        </div>
        <img src={currentProperty?.propertyImages[0]} alt="property" />
      </div>
      <div className="bookingReviewSummary__timing">
        <div className="bookingReviewSummary__date">
          <p>CHECK IN</p>
          <h2>{`${getDate(formData?.checkInDate)[1]} ${getDate(formData?.checkInDate)[2]} ${getDate(formData?.checkInDate)[3]}`}</h2>
          <p>{`${getDate(formData?.checkInDate)[0]}`}</p>
        </div>
        <div className="noofdays">
          <p>{`${night} Night`}</p>
        </div>
        <div className="bookingReviewSummary__date">
          <p>CHECK OUT</p>
          <h2>{`${getDate(formData?.checkOutDate)[1]} ${getDate(formData?.checkOutDate)[2]} ${getDate(formData?.checkOutDate)[3]}`}</h2>
          <p>{`${getDate(formData?.checkOutDate)[0]} 12:30 PM`}</p>
        </div>
        <h2>{`${formData?.adults
          } Adults & ${formData?.kids} ${formData?.kids <= 1 ? "Child" : "Children"}`}</h2>
      </div>
      {/* <div className="bookingReviewSummary__noofroom">
        <h2>1 Room</h2>
        <span>1bedroom | 1Double Bed</span>
      </div> */}
      <div className="bookingReviewSummary__roomtype">
        <div className="roomtype__content">
          <div className="room__name__content">
            <div className="room__name">
              <h3>{room?.roomName}</h3>
              {/* <p>{`${room?.noGuestsInRoom} guests per room`}</p> */}
            </div>
            {/* <h6 onClick={handleOpen}>View all rooms inclusions</h6> */}
          </div>
          <div className="divider__room" />
          <div className="roomtype__mainContent">
            <h6>Price Includes</h6>
            <ul>
              {room?.isBreakfastProvided ?
                (<li>meals included</li>) :
                (<li>No meals included</li>)
              }
              <div className="cancellation">
                <li>On cancellation, You will get refund according to </li>
                <Tooltip
                  position="right"
                  component={InlineDialog}
                  content={`A refund will be issued if the cancellation is made prior to ${room.propertyId.cancellationDays} days from the check-in date; otherwise, no refund will be provided.`}
                >
                  {(tooltipProps) => (
                    <span {...tooltipProps}>
                      <h6>Cancellation policy details</h6>
                    </span>
                  )}
                </Tooltip>
              </div>
            </ul>
          </div>
        </div>
      </div>

      {Object.keys(bill).length > 0 && (<div className="bookingReviewSummary__roomtype">
        <div className="roomtype__content">
          <div className="room__name__content">
            <div className="room__name">
              <img src={logo} alt="gosafejourney logo" />
              <h3>{room?.roomName}</h3>
              {/* <p>{`${room?.noGuestsInRoom} guests per room`}</p> */}
            </div>
            {/* <h6 onClick={handleOpen}>View all rooms inclusions</h6> */}
          </div>
          <div className="divider__room" />
          <div className="roomtype__mainContent">
            <h2>Receipt</h2>

            <h3>{`Name: ${bill?.data?.clientName}`}</h3>
            <div style={{ display: "flex", justifyContenr: "space-between" }}><h3>{`Check In: ${getDate(bill?.data?.checkInDate)[1]} ${getDate(bill?.data?.checkInDate)[2]} ${getDate(bill?.data?.checkInDate)[3]}`}</h3>  <h3>{`Check Out: ${getDate(bill?.data?.checkOutDate)[1]} ${getDate(bill?.data?.checkOutDate)[2]} ${getDate(bill?.data?.checkOutDate)[3]}`}</h3></div>
            <div style={{ display: "flex", justifyContenr: "space-between" }}><h3>{`Room Type: ${bill?.data?.roomType}`} </h3> <h3>{`Booked Rooms: ${bill?.data?.noBookedRooms}`}</h3></div>
            <h3>{`Price: ₹ ${price} + ${getTax(price)} GST`}</h3>
            <h3>{`Total amount paid: ₹ ${price + getTax(price)}`}</h3>
          </div>
        </div>
      </div>)}

      {/* <div className="bookingReviewSummary__impinfo">
        <div className="impinfo__content">
          <div className="impinfo__title">
            <h5>Important Information</h5>
          </div> */}
      {/* <div className="bookingReviewSummary__divider" />
          <div className="impinfo__rules">
            <h5>Homestay Rules</h5>
            <ul>
              <li>Passport, Aadhar, Driving License and Govt. ID are accepted as ID proof (s)</li>
              <li>Passport, Aadhar, Driving License and Govt. ID are accepted as ID proof (s)</li>
              <li>Passport, Aadhar, Driving License and Govt. ID are accepted as ID proof (s)</li>
              <li>Passport, Aadhar, Driving License and Govt. ID are accepted as ID proof (s)</li>
            </ul>
            <p>Read All Homestay Rules</p>
          </div>
        </div> */}
      {/* </div> */}
      <RoomDetailsModal open={open} room={room} setOpen={setOpen} />
    </div>
  );
}

export default BookingReviewSummary;
