import React from 'react';
import './WhySignUpBanner.scss';

function WhySignUpBanner() {
  return (
    <div className="whySignUpBanner">WhySignUpBanner</div>
  );
}

export default WhySignUpBanner;
