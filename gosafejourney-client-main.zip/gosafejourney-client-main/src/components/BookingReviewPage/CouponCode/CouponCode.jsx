import React from 'react';
import './CouponCode.scss';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';

function CouponCode() {
  return (
    <div className="CouponCode">
      <h3>COUPON CODES</h3>
      <div className="CouponCode__divider" />
      <div className="CouponCode__code">
        <input placeholder="Have a Coupon Code?" />
        <div className="CouponCode__icon">
          <ArrowForwardIcon />
        </div>
      </div>
    </div>
  );
}

export default CouponCode;
