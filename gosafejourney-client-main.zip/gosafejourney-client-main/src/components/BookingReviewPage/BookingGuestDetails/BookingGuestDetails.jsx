import React, { useState } from 'react';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import Checkbox from '@mui/material/Checkbox';
import { IconButton } from '@mui/material';
import { CloseRounded } from '@mui/icons-material';
import PhoneInput from 'react-phone-input-2';
import GuestDetailsModal from '../../GuestDetailsModal/GuestDetailsModal';
import Input from '../../Input/Input';
import 'react-phone-input-2/lib/style.css';
import './BookingGuestDetails.scss';

function BookingGuestDetails({
  handleChange, formData, setFormData, names, setNames,
}) {
  const [open, setOpen] = useState(false);
  const [openGuest, setOpenGuest] = useState(false);
  const handleOpen = () => setOpenGuest(true);
  function removeGuest(name) {
    setNames(names.filter((item) => item !== name));
  }

  const handleGSTChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.checked });
    setOpen(!open);
  };

  return (
    <div className="bookingGuestDetails">
      <div className="bookingGuestDetails__title">
        <h3>Guest Details</h3>
        <KeyboardArrowDownIcon />
      </div>
      <div className="bookingGuestDetails__divider" />
      {/* <div className="bookingGuestDetails__login">
        <h6>Login </h6>
        <p>to prefill traveler details and get access to secret deals</p>
      </div> */}
      <form>
        <div className="form__firstline">
          <div className="form__query">
            <p>TITLE</p>
            <select name="salutation" onChange={handleChange}>
              <option name="Mr.">Mr.</option>
              <option name="Ms.">Ms.</option>
              <option name="Mrs.">Mrs.</option>
            </select>
          </div>
          <div className="form__query">
            <p>FIRST NAME</p>
            <Input name="firstName" placeholder="First Name" handleChange={handleChange} />
          </div>
          <div className="form__query">
            <p>LAST  NAME</p>
            <Input name="lastName" placeholder="Last Name" handleChange={handleChange} />
          </div>
        </div>
        <div className="form__secondline">
          <div className="form__email">
            <p>EMAIL</p>
            <Input type="email" name="email" placeholder="Email" handleChange={handleChange} />
          </div>
          <div className="form__number">
            <p>MOBILE NUMBER</p>
            <PhoneInput
              country="in"
              value={formData.phone}
              onChange={handleChange}
            />
          </div>
        </div>
        <FormGroup>
          <FormControlLabel control={<Checkbox name="gst" checked={formData.gst} onChange={handleGSTChange} />} label="Enter GST Details  (Optional)" />
          {open && (
            <div className="form__thirdline">
              <div className="form__query">
                <p>REGISTRATION NUMBER</p>
                <Input name="registrationNo" placeholder="Enter Registration Number" handleChange={handleChange} />
              </div>
              <div className="form__query">
                <p>REGISTERED COMPANY NAME</p>
                <Input name="company" placeholder="Enter Company Name" handleChange={handleChange} />
              </div>
              <div className="form__query">
                <p>REGISTERED COMPANY ADDRESS</p>
                <Input name="companyAddress" placeholder="Enter Company Address" handleChange={handleChange} />
              </div>
            </div>
          )}
        </FormGroup>
      </form>
      {names.length !== 0 && (
        <div>
          <h5>Other Guests</h5>
          <div className="bookingGuestDetails__otherguests__content">
            {names.map((item) => (
              <div className="bookingGuestDetails__otherguests">
                <p>{item}</p>
                <IconButton onClick={() => removeGuest(item)}>
                  <CloseRounded />
                </IconButton>
              </div>
            ))}
          </div>
        </div>
      )}
      <h6 onClick={handleOpen}>+ Add Guest</h6>
      <GuestDetailsModal open={openGuest} setOpen={setOpenGuest} names={names} setNames={setNames} />
    </div>
  );
}

export default BookingGuestDetails;
