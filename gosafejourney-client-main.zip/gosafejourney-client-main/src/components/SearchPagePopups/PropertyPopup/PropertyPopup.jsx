import React from 'react';
import {
  Checkbox, FormControl, FormControlLabel, FormGroup,
} from '@mui/material';
import './PropertyPopup.scss';

function PropertyPopup({
  formData, handlePropertyChange, propertyVisibility, setPropertyVisibility,
}) {
  return (
    <div className="propertyPopup" style={{ display: !propertyVisibility && 'none' }}>
      <div className="propertyPopup__content">
        <FormControl>
          <FormGroup>
            <FormControlLabel value="apartment" control={<Checkbox checked={formData.stayTypes.includes('apartment')} onChange={handlePropertyChange} />} label="Apartment" />
            <FormControlLabel value="hotel" control={<Checkbox checked={formData.stayTypes.includes('hotel')} onChange={handlePropertyChange} />} label="Hotel" />
            <FormControlLabel value="villa" control={<Checkbox checked={formData.stayTypes.includes('villa')} onChange={handlePropertyChange} />} label="Villa" />
            <FormControlLabel value="resort" control={<Checkbox checked={formData.stayTypes.includes('resort')} onChange={handlePropertyChange} />} label="Resort" />
          </FormGroup>
        </FormControl>
      </div>
      <hr />
      <div className="propertyPopup__footer">
        <button type="button" onClick={() => setPropertyVisibility(false)}>Apply</button>
      </div>
    </div>
  );
}

export default PropertyPopup;
