import {
  Checkbox, FormControl, FormControlLabel, FormGroup,
} from '@mui/material';
import React from 'react';
import './PricingFilterPopup.scss';

function PricingFilterPopup({
  pricingRange, handlePricingChange, pricingVisibility, setPricingVisibility,
}) {
  return (
    <div className="pricingFilterPopup" style={{ display: !pricingVisibility && 'none' }}>
      <div className="pricingFilterPopup__content">
        <FormControl>
          <FormGroup>
            <FormControlLabel value="₹0- ₹1500" control={<Checkbox value={pricingRange} handleChange={handlePricingChange} />} label="₹0- ₹1500" />
            <FormControlLabel value="₹1500- ₹2500" control={<Checkbox />} label="₹1500- ₹2500" />
            <FormControlLabel value="₹2500- ₹5000" control={<Checkbox />} label="₹2500- ₹5000" />
            <FormControlLabel value="₹5000+" control={<Checkbox />} label="₹5000+" />
          </FormGroup>
        </FormControl>
      </div>
      <hr />
      <div className="pricingFilterPopup__footer">
        <button type="button" onClick={() => setPricingVisibility(false)}>Apply</button>
      </div>
    </div>
  );
}

export default PricingFilterPopup;
