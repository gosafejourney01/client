import React from 'react';
import { Dialog, IconButton } from '@mui/material';
import { CloseRounded } from '@mui/icons-material';
import './CancelBookingModal.scss';

function CancelbookingModal({
  open, setOpen, propertyName, handleCancellation,
}) {
  const handleClose = () => setOpen(false);

  return (
    <Dialog
      open={open}
      onClose={handleClose}
    >
      <div className="cancelBookingModal">
        <div className="cancelBookingModal__head">
          <h3>Cancellation</h3>
          <IconButton onClick={handleClose}>
            <CloseRounded />
          </IconButton>
        </div>
        <div className="cancelBookingModal__content">
          <p>
            Are you sure you want to cancel your booking at
            {' '}
            <span>{propertyName}</span>
            {' '}
            <span>, you would not get any refund for the same if you are not eligible. </span>
            For more Information Read Cancellation Policy
          </p>
          <button type="button" className="cancelBookingModal__btn" onClick={handleCancellation}>Cancel Booking</button>
        </div>
      </div>
    </Dialog>

  );
}

export default CancelbookingModal;
