import {
  FormControl, FormControlLabel, Radio, RadioGroup,
} from '@mui/material';
import React from 'react';
import './PricingPopup.scss';

function PricingPopup({
  pricingRange, handleChange, pricingVisibility, setPricingVisibility,
}) {
  return (
    <div className="pricingPopup" style={{ display: !pricingVisibility && 'none' }}>
      <div className="pricingPopup__content">
        <FormControl>
          <RadioGroup
            aria-labelledby="demo-controlled-radio-buttons-group"
            name="pricingRange"
            value={pricingRange}
            onChange={handleChange}
          >
            <FormControlLabel value="₹0- ₹1500" control={<Radio />} label="₹0- ₹1500" />
            <FormControlLabel value="₹1500- ₹2500" control={<Radio />} label="₹1500- ₹2500" />
            <FormControlLabel value="₹2500- ₹5000" control={<Radio />} label="₹2500- ₹5000" />
            <FormControlLabel value="₹5000+" control={<Radio />} label="₹5000+" />
          </RadioGroup>
        </FormControl>
      </div>
      <hr />
      <div className="pricingPopup__footer">
        <button type="button" onClick={() => setPricingVisibility(false)}>Apply</button>
      </div>
    </div>
  );
}

export default PricingPopup;
