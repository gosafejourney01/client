/* eslint-disable no-unused-vars */
import React, { useState } from 'react';
import { Edit, Tune } from '@mui/icons-material';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import moment from 'moment/moment';
import './SearchFilterHeaderMobile.scss';
import KeyboardArrowDown from '@mui/icons-material/KeyboardArrowDown';
import SearchFilterMobile from '../HomePage/SearchFilterMobile/SearchFilterMobile';
import PricingFilterPopup from '../SearchPagePopups/PricingFilterPopup/PricingFilterPopup';
import PropertyPopup from '../SearchPagePopups/PropertyPopup/PropertyPopup';

function SearchFilterHeaderMobile({
  formData, handleChange, handleCheckInCheckOutChange, handleSubmit, handlePricingChange, setFormData,
}) {
  const [propertyVisibility, setPropertyVisibility] = useState(false);
  const [pricingVisibility, setPricingVisibility] = useState(false);
  const [ratingVisibility, setRatingVisibility] = useState(false);
  const [amenitiesVisibility, setAmenitiesVisibility] = useState(false);

  const handlePropertyChange = (e) => {
    if (!e.target.checked) {
      setFormData({ ...formData, stayTypes: formData.stayTypes.filter((item) => item !== e.target.value) });
    } else {
      setFormData({ ...formData, stayTypes: [...formData.stayTypes, e.target.value] });
    }
  };

  function openEditFilters() {
    document.getElementById('searchFilterHeaderMobile__searchresults').style.display = 'none';
    document.getElementById('searchFilterHeaderMobile__edit').style.display = 'block';
  }
  return (
    <div className="searchFilterHeaderMobile">
      <div className="searchFilterHeaderMobile__content">
        <div id="searchFilterHeaderMobile__searchresults" className="searchFilterHeaderMobile__searchresults">
          <div className="searchFilterHeaderMobile__searchresultscontent">
            <KeyboardBackspaceIcon />
            <div className="searchFilterHeaderMobile__results">
              <h6>Hyderabad</h6>
              <p>
                {moment(formData.checkInDate).format('DDMMM')}
                {' '}
                -
                {' '}
                {moment(formData.checkOutDate).format('DDMMM')}
                , 1Room,
                {' '}
                {formData.adults}
                Guests
              </p>
            </div>
          </div>
          <div className="searchFilterHeaderMobile__searchresultsedit">
            <Edit />
            <p onClick={openEditFilters}>Edit</p>
          </div>
        </div>
        <form id="searchFilterHeaderMobile__edit">
          <SearchFilterMobile formData={formData} handleChange={handleChange} handleCheckInCheckOutChange={handleCheckInCheckOutChange} handleSubmit={handleSubmit} />
        </form>
        <div className="searchFilterHeaderMobile__filterscontent">
          <Tune />
          <div className="searchFilterHeaderMobile__filters" onClick={() => setPricingVisibility(!pricingVisibility)}>
            <p>Price</p>
            <KeyboardArrowDown />
            <PricingFilterPopup pricingRange={formData.pricingRange} handlePricingChange={handlePricingChange} pricingVisibility={pricingVisibility} setPricingVisibility={setPricingVisibility} />
          </div>
          <div className="searchFilterHeaderMobile__filters">
            <p>Star Rating</p>
            <KeyboardArrowDown />
          </div>
          <div className="searchFilterHeaderMobile__filters" onClick={() => setPropertyVisibility(!propertyVisibility)}>
            <p>Property Type</p>
            <KeyboardArrowDown />
            <PropertyPopup formData={formData} handlePropertyChange={handlePropertyChange} propertyVisibility={propertyVisibility} setPropertyVisibility={setPropertyVisibility} />
          </div>
          <div className="searchFilterHeaderMobile__filters">
            <p>Amenities</p>
            <KeyboardArrowDown />
          </div>
        </div>
      </div>
    </div>
  );
}

export default SearchFilterHeaderMobile;
