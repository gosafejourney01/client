import React from 'react';
import { Dialog, IconButton } from '@mui/material';
import { CloseRounded } from '@mui/icons-material';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import './GuestDetailsModal.scss';

function GuestDetailsModal({
  open, setOpen, names, setNames,
}) {
  const handleClose = () => setOpen(false);
  const myFunction = () => {
    setNames([
      ...names,
      document.getElementById('fullname').value,
    ]);
    setOpen(false);
  };
  return (
    <Dialog
      open={open}
      onClose={handleClose}
    >
      <div className="guestDetailsModal">
        <div className="guestDetailsModal__head">
          <h3>Add Guests</h3>
          <IconButton onClick={handleClose}>
            <CloseRounded />
          </IconButton>
        </div>
        <div className="guestDetailsModal__divider" />
        <div className="guestDetailsModal__content">
          <div className="guestDetailsModal__detail">
            <h4>Add Guests</h4>
            <p>Name should be as per Aadhar card or any Govt ID  travelers  below 18 years of age cannot travel alone</p>
            <form>
              <div className="form__titles">
                <p>TITLE</p>
                <select name="salutation">
                  <option>Mr.</option>
                  <option>Ms.</option>
                  <option>Mrs.</option>
                </select>
              </div>
              <div className="form__query">
                <p>FULL NAME</p>
                <input id="fullname" name="fullName" />
              </div>
            </form>
            <FormGroup>
              <FormControlLabel control={<Checkbox defaultChecked />} label="Below 12 years of age" />
            </FormGroup>
            {/* <div className="roomDetailsModal__addguest" onClick={myFunction}>
              <p>Add to saved guests</p>
            </div> */}
          </div>
        </div>
        <div className="guestDetailsModal__divider" />
        <div className="guestDetailsModal__footer">
          <button type="button" className="guestDetailsModal__btn" onClick={myFunction}>Add to saved guests</button>
        </div>
      </div>
    </Dialog>
  );
}

export default GuestDetailsModal;
