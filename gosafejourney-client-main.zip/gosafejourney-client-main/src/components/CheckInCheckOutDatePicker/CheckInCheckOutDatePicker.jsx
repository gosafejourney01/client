import React, { useEffect, useState } from 'react';
import { Calendar, utils } from '@amir04lm26/react-modern-calendar-date-picker';
import 'react-modern-calendar-datepicker/lib/DatePicker.css';
import './CheckInCheckOutDatePicker.scss';

function CheckInCheckOutDatePicker({
  setCheckInDate, setCheckOutDate, calendarVisibility, setCalendarVisibility,
}) {
  const today = new Date();
  const tomorrow = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);

  const defaultFrom = {
    year: today.getFullYear(),
    month: today.getMonth() + 1,
    day: today.getDate(),
  };

  const defaultTo = {
    year: tomorrow.getFullYear(),
    month: tomorrow.getMonth() + 1,
    day: tomorrow.getDate(),
  };

  const [selectedDayRange, setSelectedDayRange] = useState({
    from: defaultFrom,
    to: defaultTo,
  });

  useEffect(() => {
    if (selectedDayRange.from !== null && selectedDayRange.to !== null) {
      setCheckInDate(new Date(selectedDayRange.from.year, selectedDayRange.from.month - 1, selectedDayRange.from.day));
      setCheckOutDate(new Date(selectedDayRange.to.year, selectedDayRange.to.month - 1, selectedDayRange.to.day));
    }
  }, [selectedDayRange]);

  return (
    <div className="datepicker">
      <div className="datepicker__content" style={{ display: !calendarVisibility && 'none' }}>
        <Calendar
          calendarClassName="responsive-calendar"
          value={selectedDayRange}
          onChange={setSelectedDayRange}
          shouldHighlightWeekends
          minimumDate={utils().getToday()}
          colorPrimary="#0fbcf9"
          colorPrimaryLight="rgba(75, 207, 250, 0.4)"
          renderFooter={() => (
            <div className="datepicker__buttons">
              <button
                className="datepicker__action"
                type="button"
                onClick={() => {
                  setSelectedDayRange({ from: null, to: null });
                }}
              >
                Reset
              </button>
              <button
                className="datepicker__action"
                type="button"
                onClick={() => {
                  setCalendarVisibility(!calendarVisibility);
                }}
              >
                Done
              </button>
            </div>
          )}
        />
      </div>
    </div>
  );
}

export default CheckInCheckOutDatePicker;
