import { FormControl, MenuItem, Select } from '@mui/material';
import React from 'react';
import './RoomsPopup.scss';

function RoomsPopup({
  adults, kids, handleChange, roomsPopupVisibility, setRoomsPopupVisibility,
}) {
  return (
    <div className="roomsPopup" style={{ display: !roomsPopupVisibility && 'none' }}>
      <div className="roomsPopup__content">
        <div className="roomsPopup__item">
          <div className="roomsPopup__itemDetails">
            <p>Adults</p>
            <span>(Above 12 years)</span>
          </div>
          <FormControl sx={{ m: 1, minWidth: 80 }}>
            <Select
              name="adults"
              value={adults}
              onChange={handleChange}
            >
              {[...Array(40)].map((x, i) => <MenuItem key={i} value={i + 1}>{i + 1}</MenuItem>)}
            </Select>
          </FormControl>
        </div>
        <div className="roomsPopup__item">
          <div className="roomsPopup__itemDetails">
            <p>Kids</p>
            <span>(12 years & below)</span>
          </div>
          <FormControl sx={{ m: 1, minWidth: 80 }}>
            <Select
              name="kids"
              value={kids}
              onChange={handleChange}
            >
              {[...Array(41)].map((x, i) => <MenuItem key={i} value={i}>{i}</MenuItem>)}
            </Select>
          </FormControl>
        </div>
      </div>
      <hr />
      <div className="roomsPopup__footer">
        <button className="roomsPopup__applybtn" type="button" onClick={() => setRoomsPopupVisibility(false)}>Apply</button>
      </div>
    </div>
  );
}

export default RoomsPopup;
