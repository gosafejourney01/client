import React from 'react';
import './BookedRoomRules.scss';

function BookedRoomRules() {
  const propertyRules = [
    'Guests with fever are not allowed',
    'Guests from containment zones are not allowed',
    'Non-Govt IDs is not accepted as ID proof(s)',
    'Govt. ID, Passport, Aadhar and Driving License are accepted as ID proof(s)',
    'Property staff is trained on hygiene guidelines',
    'Pets are not allowed.',
  ];

  return (
    <div className="bookedRoomRules">
      <h3>House Rules</h3>
      <ul>
        {propertyRules.map((rule) => <li>{rule}</li>)}
      </ul>
    </div>
  );
}

export default BookedRoomRules;
