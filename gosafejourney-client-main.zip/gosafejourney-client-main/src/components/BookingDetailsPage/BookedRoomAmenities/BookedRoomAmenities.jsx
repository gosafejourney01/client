import React from 'react';
import caretaker from '../../../images/amenities_caretaker.svg';
import power from '../../../images/amenities_power.svg';
import tours from '../../../images/amenities_tours.svg';
import './BookedRoomAmenities.scss';

function BookedRoomAmenities() {
  return (
    <div className="bookedRoomAmenities">
      <h3>Amenities at Hotel Ocean Palms Goa</h3>
      <div className="bookedRoomAmenities__amenities">
        <div className="bookedRoomAmenities__amenity">
          <div className="bookedRoomAmenities__amenityIcon">
            <img src={caretaker} alt="caretaker" />
          </div>
          <p>Caretaker</p>
        </div>
        <div className="bookedRoomAmenities__amenity">
          <div className="bookedRoomAmenities__amenityIcon">
            <img src={power} alt="power backup" />
          </div>
          <p>Power Backup</p>
        </div>
        <div className="bookedRoomAmenities__amenity">
          <div className="bookedRoomAmenities__amenityIcon">
            <img src={tours} alt="tours" />
          </div>
          <p>Tours & Treks</p>
        </div>
      </div>
      <button type="button">View All 42 Amenities</button>
    </div>
  );
}

export default BookedRoomAmenities;
