import React from 'react';
import './BookedRoomDates.scss';

function BookedRoomDates({ bookingData }) {
  return (
    <div className="bookedRoomDates">
      <div>
        <p>Check in</p>
        <div>
          <span>
            {new Date(bookingData.checkInDate).toLocaleDateString('en-US', {
              year: 'numeric', month: 'long', day: 'numeric', timeZone: 'Asia/Kolkata',
            })}

          </span>
        </div>
      </div>
      <div>
        <p>Check out</p>
        <div>
          <span>
            {new Date(bookingData.checkOutDate).toLocaleDateString('en-US', {
              year: 'numeric', month: 'long', day: 'numeric', timeZone: 'Asia/Kolkata',
            })}

          </span>
        </div>
      </div>
      <div>
        <p>Guests</p>
        <div>
          <span>{bookingData.noBookedRooms * bookingData.roomId.noGuestsInRoom}</span>
        </div>
      </div>
      <div>
        <p>Rooms</p>
        <div>
          <span>
            {bookingData.noBookedRooms}
            {' '}
            Room
          </span>
        </div>
      </div>
    </div>
  );
}

export default BookedRoomDates;
