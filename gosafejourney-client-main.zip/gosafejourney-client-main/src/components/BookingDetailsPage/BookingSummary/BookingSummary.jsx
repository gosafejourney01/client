import React from 'react';
import BookedRoomDetails from '../BookedRoomDetails/BookedRoomDetails';
import BookedRoomDates from '../BookedRoomDates/BookedRoomDates';
import './BookingSummary.scss';
import BookedRoomRules from '../BookedRoomRules/BookedRoomRules';
import BookedRoomAmenities from '../BookedRoomAmenities/BookedRoomAmenities';

function BookingSummary({ bookingData }) {
  return (
    <div className="bookingSummary">
      <BookedRoomDetails bookingData={bookingData} />
      <div className="bookingSummary__divider" />
      <BookedRoomDates bookingData={bookingData} />
      <div className="bookingSummary__divider" />
      <BookedRoomRules />
      <div className="bookingSummary__divider" />
      <BookedRoomAmenities />
    </div>
  );
}

export default BookingSummary;
