import React from 'react';
import HomeOutlinedIcon from '@mui/icons-material/HomeOutlined';
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';
import CircleIcon from '@mui/icons-material/Circle';
/* import offer2 from '../../../images/offer2.png'; */
import './BookedRoomDetails.scss';

function BookedRoomDetails({ bookingData }) {
  return (
    <div className="bookedRoomDetails">
      <div className="bookedRoom__hotel">
        <img src={bookingData?.roomId?.propertyId?.propertyImages[0]} alt="hotel room" />
        <div className="bookedRoom__bookingDetails">
          <div className="bookedRoom__hotelDetails">
            <h3>{bookingData?.roomId?.propertyId?.propertyName}</h3>
            <div className="bookedRoom__hotelLocation">
              <span>{bookingData?.roomId?.propertyId?.city}</span>
              {/* <p> | 7-8 minutes walk to Calangute Beach</p> */}
            </div>
            <div className="bookedRoom__hotelFeatures">
              {/* <span className="bookedRoom__hotelType">{bookingData.roomId.propertyId.propertyType}</span> */}
              <span className="bookedRoom__hotelType">RESORT</span>
              {/* <span className="bookedRoom__hotelRule">Couple Friendly</span> */}
            </div>
            <div className="bookedRoom__features">
              <div>
                <HomeOutlinedIcon />
                <p>Private Room</p>
              </div>
              <div>
                <PersonOutlineIcon />
                <p>
                  {bookingData.noBookedRooms * bookingData.roomId.noGuestsInRoom}
                  {' '}
                  Guests
                </p>
              </div>
            </div>
            <div className="bookedRoom__rating">
              <span>{bookingData?.roomId?.propertyId?.rating}</span>
              {Number(bookingData?.roomId?.propertyId?.rating[0]) <= 2 && (
                <p>Bad</p>
              )}
              {Number(bookingData?.roomId?.propertyId?.rating[0]) <= 4 && (
                <p>Good</p>
              )}
              {Number(bookingData?.roomId?.propertyId?.rating[0]) === 5 && (
                <p>Excellent</p>
              )}
            </div>
          </div>
          <div className={`bookedRoom__${bookingData?.bookingStatus.toLowerCase()}`}>
            <CircleIcon />
            {bookingData?.bookingStatus.toLowerCase() === 'active' && (
              <p>Active</p>
            )}
            {bookingData?.bookingStatus.toLowerCase() === 'cancelled' && (
              <p>Cancelled</p>
            )}
            {bookingData?.bookingStatus.toLowerCase() === 'completed' && (
              <p>Completed</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default BookedRoomDetails;
