import React from 'react';
import { useNavigate } from 'react-router-dom';
import nobookings from '../../../images/nobookings.svg';
import './NoBookingsScreen.scss';

function NoBookingsScreen() {
  const navigate = useNavigate();
  return (
    <div className="emptyBooking">
      <div className="emptyBooking__content">
        <img src={nobookings} alt="empty" />
        <div className="emptyBooking__maincontent">
          <div className="emptyBooking__details">
            <h4>Looks empty, you’ve no upcoming bookings</h4>
            <p>When you book a trip, you will see your bookings here</p>
          </div>
          <button type="button" className="emptyBooking__btn" onClick={() => { navigate('/'); }}>PLAN A TRIP</button>
        </div>
      </div>
    </div>
  );
}

export default NoBookingsScreen;
