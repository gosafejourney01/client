import React, { useState, useEffect } from 'react';
import EventIcon from '@mui/icons-material/Event';
import CancelPresentationIcon from '@mui/icons-material/CancelPresentation';
import ListAltIcon from '@mui/icons-material/ListAlt';
import axios from 'axios';
import BookedRoomCard from '../BookedRoomCard/BookedRoomCard';
import NoBookingsScreen from '../NoBookingsScreen/NoBookingsScreen';
import './BookingStatusSection.scss';

function BookingStatusSection() {
  const [bookedRoomCompletedArray, setBookedRoomCompletedArray] = useState([]);
  const [bookedRoomActiveArray, setBookedRoomActiveArray] = useState([]);
  const [bookedRoomCancelledArray, setBookedRoomCancelledArray] = useState([]);
  const [bookingstatus, setBookingstatus] = useState('active');

  useEffect(() => {
    const getAllBookings = async () => {
      // eslint-disable-next-line no-underscore-dangle
      const userToken = JSON.parse(localStorage.getItem('profile')).token;
      axios
        .get(`${process.env.REACT_APP_SERVER_URL}/property-bookings`, {
          headers: {
            authorization: `Bearer ${userToken}`,
          },
        })
        .then((response) => {
          console.log('response', response);
          const { data } = response;
          const completedBookings = data.filter(
            (booking) => booking.bookingStatus.toLowerCase() === 'completed',
          );
          const activeBookings = data.filter(
            (booking) => booking.bookingStatus.toLowerCase() === 'active',
          );
          const cancelledBookings = data.filter(
            (booking) => booking.bookingStatus.toLowerCase() === 'cancelled',
          );
          setBookedRoomCompletedArray(completedBookings);
          setBookedRoomActiveArray(activeBookings);
          setBookedRoomCancelledArray(cancelledBookings);
        });
    };
    getAllBookings();
  }, []);

  function bookingState(bookingStatus) {
    setBookingstatus(bookingStatus);
  }
  return (
    <div className="bookingStatus">
      <div className="bookingStatus_head">
        <div className="bookingStatus_headcontent">
          <div
            onClick={() => bookingState('active')}
            className={
              bookingstatus === 'active'
                ? 'bookingStatus__onclick'
                : 'bookingStatus_status'
            }
          >
            <EventIcon />
            <h5>Bookings</h5>
          </div>
          <div
            onClick={() => bookingState('cancelled')}
            className={
              bookingstatus === 'cancelled'
                ? 'bookingStatus__onclick'
                : 'bookingStatus_status'
            }
          >
            <CancelPresentationIcon />
            <h5>Cancelled</h5>
          </div>
          <div
            onClick={() => bookingState('completed')}
            className={
              bookingstatus === 'completed'
                ? 'bookingStatus__onclick'
                : 'bookingStatus_status'
            }
          >
            <ListAltIcon />
            <h5>Completed</h5>
          </div>
        </div>
      </div>
      <div className="bookingStatus__divider" />
      {bookingstatus === 'active' ? (
        <div>
          {bookedRoomActiveArray.length === 0 ? (
            <NoBookingsScreen />
          ) : (
            bookedRoomActiveArray.map((card) => (
              <div>
                <BookedRoomCard
                  // eslint-disable-next-line no-underscore-dangle
                  bookingId={card._id}
                  roomId={card.roomId._id}
                  checkInDate={card.checkInDate}
                  checkOutDate={card.checkOutDate}
                  bookingstatus="active"
                />
              </div>
            ))
          )}
        </div>
      ) : (
        <div />
      )}
      {bookingstatus === 'completed' ? (
        <div>
          {bookedRoomCompletedArray.length === 0 ? (
            <NoBookingsScreen />
          ) : (
            bookedRoomCompletedArray.map((card) => (
              <div>
                <BookedRoomCard
                  // eslint-disable-next-line no-underscore-dangle
                  bookingId={card._id}
                  roomId={card.roomId._id}
                  checkInDate={card.checkInDate}
                  checkOutDate={card.checkOutDate}
                  bookingstatus="completed"
                />
              </div>
            ))
          )}
        </div>
      ) : (
        <div />
      )}
      {bookingstatus === 'cancelled' ? (
        <div>
          {bookedRoomCancelledArray.length === 0 ? (
            <NoBookingsScreen />
          ) : (
            bookedRoomCancelledArray.map((card) => (
              <div>
                <BookedRoomCard
                  // eslint-disable-next-line no-underscore-dangle
                  bookingId={card._id}
                  roomId={card.roomId._id}
                  checkInDate={card.checkInDate}
                  checkOutDate={card.checkOutDate}
                  bookingstatus="cancelled"
                />
              </div>
            ))
          )}
        </div>
      ) : (
        <div />
      )}
    </div>
  );
}

export default BookingStatusSection;
