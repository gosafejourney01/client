import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import CloseIcon from '@mui/icons-material/Close';
import DoneIcon from '@mui/icons-material/Done';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import CircleIcon from '@mui/icons-material/Circle';
import moment from 'moment';
import { getBooking } from '../../../actions/booking';
/* import offer2 from '../../../images/offer2.png';
import CancelBookingModal from '../../CancelBookingModal/CancelBookingModal'; */
import './BookedRoomCard.scss';

function BookedRoomCard({
  bookingId,
  roomId,
  checkInDate,
  checkOutDate,
  bookingstatus = 'active',
}) {
  const [room, setRoom] = useState({});
  // eslint-disable-next-line no-unused-vars
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);

  const dispatch = useDispatch();
  const navigate = useNavigate();

  useEffect(() => {
    const getRoom = async () => {
      const res = await fetch(`${process.env.REACT_APP_SERVER_URL}/rooms/${roomId}`);

      const data = await res.json();
      setRoom(data);
    };

    getRoom();
  }, [roomId]);

  return (
    // eslint-disable-next-line no-underscore-dangle
    <div className="bookedRoomCard" onClick={() => dispatch(getBooking(bookingId, () => { navigate('/booking-details'); }))}>
      <div className="bookedRoomCard__hotel">
        <img src={room?.images?.[0]} alt="hotel room" />
        <div className="bookedRoomCard__bookingDetails">
          <div className="bookedRoomCard__hotelDetails">
            <h3>{room?.roomName}</h3>
            <div className="bookedRoomCard__hotelLocation">
              <span>{room?.roomType}</span>
              {/* <p> | 7-8 minutes walk to Calangute Beach</p> */}
            </div>
            <div className="bookedRoomCard__hotelFeatures">
              <span className="bookedRoomCard__hotelType">
                {room?.roomType}
              </span>
            </div>
            <div className="bookedRoomCard__features">
              <div>
                <CalendarMonthIcon />
                <p>
                  {moment(checkInDate).format('D MMM, YYYY')}
                  {' '}
                  -
                  {' '}
                  {moment(checkOutDate).format('D MMM, YYYY')}
                </p>
              </div>
            </div>
            <h5>{`Booking Id : ${bookingId}`}</h5>
            {bookingstatus.toLowerCase() === 'active' && (
              <div
                onClick={handleOpen}
                className="bookedRoomCard__activebooking"
              >
                <CloseIcon />
                <p>Cancel Booking</p>
              </div>
            )}
            {bookingstatus.toLowerCase() === 'cancelled' && (
              <div className="bookedRoomCard__cancelbooking">
                <CloseIcon />
                <p>Cancelled Booking</p>
              </div>
            )}
            {bookingstatus.toLowerCase() === 'completed' && (
              <div className="bookedRoomCard__completedbooking">
                <DoneIcon />
                <p>Completed</p>
              </div>
            )}
          </div>
          <div className={`bookedRoomCard__${bookingstatus}`}>
            <CircleIcon />
            {bookingstatus.toLowerCase() === 'active' && <p>Active</p>}
            {bookingstatus.toLowerCase() === 'cancelled' && <p>Cancelled</p>}
            {bookingstatus.toLowerCase() === 'completed' && <p>Completed</p>}
          </div>
        </div>
      </div>
      {/* <CancelBookingModal
        open={open}
        setOpen={setOpen}
        propertyName={propertyName}
      /> */}
    </div>
  );
}

export default BookedRoomCard;
