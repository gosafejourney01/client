import React from 'react';
import { useLocation } from 'react-router-dom';
import CircleIcon from '@mui/icons-material/Circle';
import { Dialog, IconButton } from '@mui/material';
import { CloseRounded } from '@mui/icons-material';
import './RoomDetailsModal.scss';

function RoomDetailsModal({ open, setOpen, room }) {
  const handleClose = () => setOpen(false);
  const location = useLocation();

  return (
    <Dialog
      open={open}
      onClose={handleClose}
    >
      <div className="roomDetailsModal">
        <div className="roomDetailsModal__head">
          {location.pathname === '/booking' ? (
            <h3>Rooms inclusions</h3>
          ) : (
            <h3>Triple Room</h3>
          )}
          <IconButton onClick={handleClose}>
            <CloseRounded />
          </IconButton>
        </div>
        <div className="roomDetailsModal__separator" />
        <div className="roomDetailsModal__content">
          <div className="roomDetailsModal__detail roomDetailsModal__norefund">
            <CircleIcon />
            <p>This booking is non-refundable and the tariff cannot be cancelled with zero fee.</p>
          </div>
          <div className="roomDetailsModal__separator" />
          {room?.isBreakfastProvided
          && (
          <div className="roomDetailsModal__detail">
            <CircleIcon />
            <p>Free Breakfast</p>
          </div>
          )}
          <div className="roomDetailsModal__separator" />
          <div className="roomDetailsModal__detail">
            <CircleIcon />
            <p>Offer applicable</p>
          </div>
        </div>
      </div>
    </Dialog>
  );
}

export default RoomDetailsModal;
