import React from 'react';
import Slider from 'react-slick';
import PropertyTypeCard from '../PropertyTypeCard/PropertyTypeCard';
import type1 from '../../../images/hotels.png';
import type2 from '../../../images/apartments.png';
import type3 from '../../../images/resorts.png';
import type4 from '../../../images/villas.png';

import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import './PropertyTypes.scss';

function PropertyTypes() {
  const settings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 4,
    initialSlide: 0,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          infinite: true,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
          infinite: true,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true,
          arrows: false,
          dots: true,
        },
      },
    ],
  };

  return (
    <div className="propertyTypes">
      <div className="propertyTypes__content">
        <h2>Property Type</h2>
        <p>Now choose any stay you love !</p>
        <Slider {...settings}>
          <PropertyTypeCard image={type1} propertyName="Hotels" />
          <PropertyTypeCard image={type2} propertyName="Apartments" />
          <PropertyTypeCard image={type3} propertyName="Resorts" />
          <PropertyTypeCard image={type4} propertyName="Villas" />
          <PropertyTypeCard image={type1} propertyName="Hotels" />
          <PropertyTypeCard image={type2} propertyName="Apartments" />
          <PropertyTypeCard image={type3} propertyName="Resorts" />
          <PropertyTypeCard image={type4} propertyName="Villas" />
        </Slider>
      </div>
    </div>
  );
}

export default PropertyTypes;
