import React from 'react';
import lowrates from '../../../images/lowrates.svg';
import support from '../../../images/support.svg';
import securebooking from '../../../images/securebooking.svg';
import confirmation from '../../../images/appointment.svg';
import './WhyUs.scss';

function WhyUs() {
  return (
    <div className="whyUs">
      <div className="whyUs__content">
        <h2>Why Us</h2>
        <div className="whyUs__reasons">
          <div className="whyUs__reason">
            <div className="whyUs__icon">
              <img src={lowrates} alt="low rates" />
            </div>
            <h4>Low Rates</h4>
            <p>
              We guarantees to offer you the best available rates.
              And with our promise to price match,
              you can rest assured that you’re always getting a great deal.
            </p>
          </div>
          <div className="whyUs__reason">
            <div className="whyUs__icon">
              <img src={securebooking} alt="secure booking" />
            </div>
            <h4>Secure Booking</h4>
            <p>
              We facilitate hundreds of thousands of transactions every day
              through our secure platform, and work to the highest
              standards to guarantee your privacy.
            </p>
          </div>
          <div className="whyUs__reason">
            <div className="whyUs__icon">
              <img src={support} alt="support" />
            </div>
            <h4>24/7 Support</h4>
            <p>
              Whether you’ve just booked or are already enjoying your trip,
              our customer experience team are on hand around the clock to
              answer your questions and advocate on your behalf.
            </p>
          </div>
          <div className="whyUs__reason">
            <div className="whyUs__icon">
              <img src={confirmation} alt="instant confirmation" />
            </div>
            <h4>Instant Confirmation</h4>
            <p>
              At Booking.com, every reservation is instantly confirmed.
              Once you’ve found your perfect stay, a few clicks are all it takes.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default WhyUs;
