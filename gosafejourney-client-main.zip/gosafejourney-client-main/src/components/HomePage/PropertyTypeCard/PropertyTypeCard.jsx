import React from 'react';
import './PropertyTypeCard.scss';

function PropertyTypeCard({ image, propertyName }) {
  return (
    <div className="propertyTypeCard">
      <img src={image} alt="property type" />
      <h3>{propertyName}</h3>
      <p>
        250+
        {' '}
        {propertyName}
      </p>
    </div>
  );
}

export default PropertyTypeCard;
