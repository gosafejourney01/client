import React from 'react';
import Slider from 'react-slick';
import TestimonialCard from '../TestimonialCard/TestimonialCard';
import profile1 from '../../../images/profile1.png';
import profile2 from '../../../images/profile2.png';
import profile3 from '../../../images/profile3.png';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import './Testimonials.scss';

function Testimonials() {
  const settings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 3,
    initialSlide: 0,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
          infinite: true,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true,
          arrows: false,
          dots: true,
        },
      },
    ],
  };

  return (
    <div className="testimonials">
      <div className="testimonials__content">
        <h2>Testimonials</h2>
        <p>
          Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint.
          Velit officia consequat duis enim velit mollit.
          Exercitation veniam consequat sunt nostrud amet.
        </p>
        <Slider {...settings}>
          <TestimonialCard profile={profile1} profileName="Matthew Johnson" profilePosition="CEO MaxiHealth" />
          <TestimonialCard profile={profile2} profileName="Andy King" profilePosition="Founder RumahSehat" />
          <TestimonialCard profile={profile3} profileName="Jack Anderson" profilePosition="CEO Apple Inc" />
          <TestimonialCard profile={profile1} profileName="Matthew Johnson" profilePosition="CEO MaxiHealth" />
          <TestimonialCard profile={profile2} profileName="Andy King" profilePosition="Founder RumahSehat" />
          <TestimonialCard profile={profile3} profileName="Jack Anderson" profilePosition="CEO Apple Inc" />
          <TestimonialCard profile={profile1} profileName="Matthew Johnson" profilePosition="CEO MaxiHealth" />
          <TestimonialCard profile={profile2} profileName="Andy King" profilePosition="Founder RumahSehat" />
          <TestimonialCard profile={profile3} profileName="Jack Anderson" profilePosition="CEO Apple Inc" />
        </Slider>
      </div>
    </div>
  );
}

export default Testimonials;
