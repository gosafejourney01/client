import { Avatar } from '@mui/material';
import React from 'react';
import testimonialIcon from '../../../images/testimonial-icon.svg';
import './TestimonialCard.scss';

function TestimonialCard({ profile, profileName, profilePosition }) {
  return (
    <div className="testimonialCard">
      <div className="testimonialCard__testimonial">
        <img src={testimonialIcon} alt="testimonial" />
        <p>
          Amet minim mollit non deserunt ullamco est sit aliqua dolor
          do amet sint. Velit officia consequat duis enim velit mollit.
        </p>
      </div>
      <div className="testimonialCard__testimonialProfile">
        <Avatar src={profile} alt="user profile" />
        <p className="testimonialCard__profileName">{profileName}</p>
        <p>{profilePosition}</p>
      </div>
    </div>
  );
}

export default TestimonialCard;
