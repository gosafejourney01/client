import React from 'react';
import Slider from 'react-slick';
import hotelStayType from '../../../images/staytype_hotel.svg';
import apartmentStayType from '../../../images/staytype_apartments.svg';
import resortStayType from '../../../images/staytype_resorts.svg';
// import villaStayType from '../../../images/staytype_villas.svg';
// import cottageStayType from '../../../images/staytype_cottage.svg';
import guesthouseStayType from '../../../images/staytype_guesthouse.svg';
// import hostelStayType from '../../../images/staytype_hostel.svg';
// import campsiteStayType from '../../../images/staytype_campsite.svg';
import './StayTypes.scss';

function StayTypes({ handleStayTypeChange }) {
  const settings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    initialSlide: 0,
    arrows: true,
    responsive: [
      {
        breakpoint: 588,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
          infinite: true,
        },
      },
      {
        breakpoint: 436,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          infinite: true,
        },
      },
    ],
  };

  const handleClick = (e, stayType) => {
    e.currentTarget.classList.toggle('stayTypes__typeSelected');
    handleStayTypeChange(stayType);
  };

  return (
    <div className="stayTypes">
      <Slider {...settings}>
        <div className="stayTypes__type" onClick={(e) => handleClick(e, 'hotel')}>
          <img src={hotelStayType} alt="hotel" />
          <p>Hotels</p>
        </div>
        <div className="stayTypes__type" onClick={(e) => handleClick(e, 'resort')}>
          <img src={resortStayType} alt="resort" />
          <p>Resorts</p>
        </div>
        <div className="stayTypes__type" onClick={(e) => handleClick(e, 'guest-house')}>
          <img src={guesthouseStayType} alt="guest-house" />
          <p>Guest House</p>
        </div>
        <div className="stayTypes__type" onClick={(e) => handleClick(e, 'apartment')}>
          <img src={apartmentStayType} alt="apartment" />
          <p>Service Apartments</p>
        </div>
      </Slider>
    </div>
  );
}

export default StayTypes;
