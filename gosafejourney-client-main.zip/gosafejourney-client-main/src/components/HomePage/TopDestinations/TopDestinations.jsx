import React from 'react';
import { useNavigate } from 'react-router-dom';
import delhi from '../../../images/delhi.png';
import hyderabad from '../../../images/hyderabad.png';
import kolkata from '../../../images/kolkata.png';
import bangalore from '../../../images/bangalore.png';
import goa from '../../../images/goa.png';
import mumbai from '../../../images/mumbai.png';
import './TopDestinations.scss';

function TopDestinations({ formData, setFormData }) {
  const navigate = useNavigate();
  function handleSubmit(e, loc) {
    e.preventDefault();
    setFormData({
      ...formData,
      location: loc,
    });
    navigate('/property-search');
  }

  return (
    <div className="topdestinations">
      <div className="topdestinations__content">
        <h2>Top Destinations</h2>
        <p>View some of our popular places which people love to visit</p>
        <div className="topdestinations__columns">
          <div className="topdestinations__column">
            <div className="topdestinations__monorow">
              <div className="topdestinations__image" onClick={(e) => handleSubmit(e, 'Delhi')}>
                <img src={delhi} alt="delhi" />
                <div className="topdestinations__imagetext">Delhi</div>
              </div>
            </div>
            <div className="topdestinations__multirow">
              <div className="topdestinations__image" onClick={(e) => handleSubmit(e, 'Hyderabad')}>
                <img src={hyderabad} alt="hyderabad" />
                <div className="topdestinations__imagetext">Hyderabad</div>
              </div>
              <div className="topdestinations__image" onClick={(e) => handleSubmit(e, 'Kolkata')}>
                <img src={kolkata} alt="kolkata" />
                <div className="topdestinations__imagetext">Kolkata</div>
              </div>
            </div>
          </div>
          <div className="topdestinations__column">
            <div className="topdestinations__multirow">
              <div className="topdestinations__image" onClick={(e) => handleSubmit(e, 'Bangalore')}>
                <img src={bangalore} alt="bangalore" />
                <div className="topdestinations__imagetext">Bangalore</div>
              </div>
              <div className="topdestinations__image" onClick={(e) => handleSubmit(e, 'Goa')}>
                <img src={goa} alt="goa" />
                <div className="topdestinations__imagetext">Goa</div>
              </div>
            </div>
            <div className="topdestinations__monorow">
              <div className="topdestinations__image" onClick={(e) => handleSubmit(e, 'Mumbai')}>
                <img src={mumbai} alt="mumbai" />
                <div className="topdestinations__imagetext">Mumbai</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default TopDestinations;
