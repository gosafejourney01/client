import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import SearchFilter from '../SearchFilter/SearchFilter';
import SearchFilterMobile from '../SearchFilterMobile/SearchFilterMobile';
import StayTypes from '../StayTypes/StayTypes';
import './PropertySearch.scss';
import getProperties from '../../../actions/property';

function PropertySearch({
  formData, handleChange, setFormData, handleCheckInCheckOutChange, handleStayTypeChange,
}) {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(getProperties(formData, () => { navigate('/property-search'); }));
  };

  return (
    <div className="propertysearch">
      <div className="propertysearch__content">
        <form onSubmit={handleSubmit}>
          <StayTypes handleStayTypeChange={handleStayTypeChange} />
          <SearchFilter formData={formData} setFormData={setFormData} handleChange={handleChange} handleCheckInCheckOutChange={handleCheckInCheckOutChange} />
          <SearchFilterMobile formData={formData} handleChange={handleChange} handleCheckInCheckOutChange={handleCheckInCheckOutChange} handleSubmit={handleSubmit} />
        </form>
      </div>
    </div>
  );
}

export default PropertySearch;
