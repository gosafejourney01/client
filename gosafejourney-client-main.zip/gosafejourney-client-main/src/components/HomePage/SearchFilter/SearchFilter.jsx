import React, { useEffect, useState } from 'react';
import moment from 'moment/moment';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import { Calendar, utils } from '@amir04lm26/react-modern-calendar-date-picker';
import 'react-modern-calendar-datepicker/lib/DatePicker.css';
import PricingPopup from '../../PricingPopup/PricingPopup';
import RoomsPopup from '../../RoomsPopup/RoomsPopup';
import './SearchFilter.scss';

function SearchFilter({
  formData, handleChange, handleCheckInCheckOutChange,
}) {
  const [calendarVisibility, setCalendarVisibility] = useState(false);
  const [pricingVisibility, setPricingVisibility] = useState(false);
  const [roomsPopupVisibility, setRoomsPopupVisibility] = useState(false);

  const defaultFrom = {
    year: formData.checkInDate.getFullYear(),
    month: formData.checkInDate.getMonth() + 1,
    day: formData.checkInDate.getDate(),
  };

  const defaultTo = {
    year: formData.checkOutDate.getFullYear(),
    month: formData.checkOutDate.getMonth() + 1,
    day: formData.checkOutDate.getDate(),
  };

  const [selectedDayRange, setSelectedDayRange] = useState({
    from: defaultFrom,
    to: defaultTo,
  });

  useEffect(() => {
    if (selectedDayRange.from !== null && selectedDayRange.to !== null) {
      handleCheckInCheckOutChange(new Date(selectedDayRange.from.year, selectedDayRange.from.month - 1, selectedDayRange.from.day), new Date(selectedDayRange.to.year, selectedDayRange.to.month - 1, selectedDayRange.to.day));
    }
  }, [selectedDayRange]);

  return (
    <div className="searchFilter">
      <div className="searchFilter__content">
        <h4>
          Book Your Stay
          {' '}
          {/* <a href="https://gosafejourney-partner.vercel.app">Click Here</a> */}
        </h4>
        <div className="searchFilter__filters">
          <div className="searchFilter__filter">
            <div className="searchFilter__filterName">
              <p>CITY, PROPERTY NAME OR LOCATION</p>
            </div>
            <h2>
              <input type="text" placeholder="Search." name="location" value={formData.location} onChange={handleChange} />
            </h2>
          </div>
          <div className="searchFilter__seperation" />
          <div className="searchFilter__filter">
            <div className="searchFilter__filterName" onClick={() => setCalendarVisibility(!calendarVisibility)}>
              <p>CHECK IN</p>
              <KeyboardArrowDownIcon />
            </div>
            <div className="datepicker">
              <div className="datepicker__content" style={{ display: !calendarVisibility && 'none' }}>
                <Calendar
                  calendarClassName="responsive-calendar"
                  value={selectedDayRange}
                  onChange={setSelectedDayRange}
                  shouldHighlightWeekends
                  minimumDate={utils().getToday()}
                  colorPrimary="#0fbcf9"
                  colorPrimaryLight="rgba(75, 207, 250, 0.4)"
                  renderFooter={() => (
                    <div className="datepicker__buttons">
                      <button
                        className="datepicker__action"
                        type="button"
                        onClick={() => {
                          setSelectedDayRange({ from: null, to: null });
                        }}
                      >
                        Reset
                      </button>
                      <button
                        className="datepicker__action"
                        type="button"
                        onClick={() => {
                          setCalendarVisibility(!calendarVisibility);
                        }}
                      >
                        Done
                      </button>
                    </div>
                  )}
                />
              </div>
            </div>
            <h3>{moment(formData.checkInDate).format('D MMM, YYYY')}</h3>
            <h5>{moment(formData.checkInDate).format('dddd')}</h5>
          </div>
          <div className="searchFilter__seperation" />
          <div className="searchFilter__filter">
            <div className="searchFilter__filterName" onClick={() => setCalendarVisibility(!calendarVisibility)}>
              <p>CHECK OUT</p>
              <KeyboardArrowDownIcon />
            </div>
            <h3>{moment(formData.checkOutDate).format('D MMM, YYYY')}</h3>
            <h5>{moment(formData.checkOutDate).format('dddd')}</h5>
          </div>
          <div className="searchFilter__seperation" />
          <div className="searchFilter__filter">
            <div className="searchFilter__filterName" onClick={() => setRoomsPopupVisibility(!roomsPopupVisibility)}>
              <p>GUESTS</p>
              <KeyboardArrowDownIcon />
            </div>
            <h3>
              {formData.adults}
              {' '}
              {formData.adults === 1 ? 'Adult' : 'Adults'}
              {' '}
              {formData.kids !== 0 && (
                <>
                  &
                  {' '}
                  {formData.kids}
                  {' '}
                  Children
                </>
              )}
            </h3>
            <RoomsPopup adults={formData.adults} kids={formData.kids} handleChange={handleChange} roomsPopupVisibility={roomsPopupVisibility} setRoomsPopupVisibility={setRoomsPopupVisibility} />
          </div>
          <div className="searchFilter__seperation" />
          <div className="searchFilter__filter" onClick={() => setPricingVisibility(!pricingVisibility)}>
            <div className="searchFilter__filterName">
              <p>PRICE PER NIGHT</p>
              <KeyboardArrowDownIcon />
            </div>
            {formData.pricingRange === null ? (
              <h4>₹0- ₹1500, ₹1500-₹2500..</h4>
            ) : (
              <h3>{formData.pricingRange}</h3>
            )}
            <PricingPopup pricingRange={formData.pricingRange} handleChange={handleChange} pricingVisibility={pricingVisibility} setPricingVisibility={setPricingVisibility} />
          </div>
        </div>
        <button type="submit" className="searchFilter__searchbtn">Search</button>
      </div>
    </div>
  );
}

export default SearchFilter;
