import React from 'react';
import './OfferCard.scss';

function OfferCard({ image }) {
  return (
    <div className="offerCard">
      <img src={image} alt="offer" />
      <div className="offerCard__imagetext">
        <div>
          <h3>Save 15% with Late Escape Deals</h3>
          <p>Tick one more destination off your wishlist</p>
        </div>
        <button type="button">
          CODE : GOSAFE
        </button>
      </div>
    </div>
  );
}

export default OfferCard;
