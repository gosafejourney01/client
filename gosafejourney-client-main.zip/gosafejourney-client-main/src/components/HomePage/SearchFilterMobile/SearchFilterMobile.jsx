import React, { useEffect, useState } from 'react';
import moment from 'moment';
import LocationOnOutlinedIcon from '@mui/icons-material/LocationOnOutlined';
import CalendarTodayOutlinedIcon from '@mui/icons-material/CalendarTodayOutlined';
import PersonOutlineOutlinedIcon from '@mui/icons-material/PersonOutlineOutlined';
import { Calendar, utils } from '@amir04lm26/react-modern-calendar-date-picker';
import 'react-modern-calendar-datepicker/lib/DatePicker.css';
import RoomsPopup from '../../RoomsPopup/RoomsPopup';
import './SearchFilterMobile.scss';

function SearchFilterMobile({
  formData, handleChange, handleCheckInCheckOutChange, handleSubmit,
}) {
  const [calendarVisibility, setCalendarVisibility] = useState(false);
  const [roomsPopupVisibility, setRoomsPopupVisibility] = useState(false);
  const [isLowerRange, setIsLowerRange] = useState(formData.pricingRange === '₹0- ₹1500');
  const [isMediumLowerRange, setIsMediumLowerRange] = useState(formData.pricingRange === '₹1500- ₹2500');
  const [isMediumHigherRange, setIsMediumHigherRange] = useState(formData.pricingRange === '₹2500- ₹5000');
  const [isHigherRange, setIsHigherRange] = useState(formData.pricingRange === '₹5000+');

  const defaultFrom = {
    year: formData.checkInDate.getFullYear(),
    month: formData.checkInDate.getMonth() + 1,
    day: formData.checkInDate.getDate(),
  };

  const defaultTo = {
    year: formData.checkOutDate.getFullYear(),
    month: formData.checkOutDate.getMonth() + 1,
    day: formData.checkOutDate.getDate(),
  };

  const [selectedDayRange, setSelectedDayRange] = useState({
    from: defaultFrom,
    to: defaultTo,
  });

  useEffect(() => {
    if (selectedDayRange.from !== null && selectedDayRange.to !== null) {
      handleCheckInCheckOutChange(new Date(selectedDayRange.from.year, selectedDayRange.from.month - 1, selectedDayRange.from.day), new Date(selectedDayRange.to.year, selectedDayRange.to.month - 1, selectedDayRange.to.day));
    }
  }, [selectedDayRange]);

  const setLowerPriceRange = () => {
    setIsLowerRange(!isLowerRange);
    setIsHigherRange(false);
    setIsMediumLowerRange(false);
    setIsMediumHigherRange(false);
    const property = { target: { name: 'pricingRange', value: '₹0- ₹1500' } };
    handleChange(property);
  };

  const setHigherPriceRange = () => {
    setIsLowerRange(false);
    setIsHigherRange(!isHigherRange);
    setIsMediumLowerRange(false);
    setIsMediumHigherRange(false);
    const property = { target: { name: 'pricingRange', value: '₹5000+' } };
    handleChange(property);
  };

  const setMediumLowerPriceRange = () => {
    setIsLowerRange(false);
    setIsHigherRange(false);
    setIsMediumLowerRange(!isMediumLowerRange);
    setIsMediumHigherRange(false);
    const property = { target: { name: 'pricingRange', value: '₹1500- ₹2500' } };
    handleChange(property);
  };

  const setMediumHigherPriceRange = () => {
    setIsLowerRange(false);
    setIsHigherRange(false);
    setIsMediumLowerRange(false);
    setIsMediumHigherRange(!isMediumHigherRange);
    const property = { target: { name: 'pricingRange', value: '₹2500- ₹5000' } };
    handleChange(property);
  };

  return (
    <div className="searchFilterMobile">
      <h2>Hotels & Accomodation</h2>
      <p>India</p>
      <div className="searchFilterMobile__filter">
        <LocationOnOutlinedIcon />
        <div className="searchFilterMobile__location">
          <h5>City/Area/Property Name</h5>
          <h4>Hyderabad</h4>
          <p>India</p>
        </div>
      </div>
      <div className="searchFilterMobile__dates">
        <div className="searchFilterMobile__filter">
          <CalendarTodayOutlinedIcon onClick={() => setCalendarVisibility(!calendarVisibility)} />
          <div role="button" className="searchFilterMobile__date" onClick={() => setCalendarVisibility(!calendarVisibility)}>
            <h5>Check-In</h5>
            <h4>{moment(formData.checkInDate).format('D MMM')}</h4>
            <p>{moment(formData.checkInDate).format('ddd, YYYY')}</p>
          </div>
          <div className="datepicker">
            <div className="datepicker__content" style={{ display: !calendarVisibility && 'none' }}>
              <Calendar
                calendarClassName="responsive-calendar"
                value={selectedDayRange}
                onChange={setSelectedDayRange}
                shouldHighlightWeekends
                minimumDate={utils().getToday()}
                colorPrimary="#0fbcf9"
                colorPrimaryLight="rgba(75, 207, 250, 0.4)"
                renderFooter={() => (
                  <div className="datepicker__buttons">
                    <button
                      className="datepicker__action"
                      type="button"
                      onClick={() => {
                        setSelectedDayRange({ from: null, to: null });
                      }}
                    >
                      Reset
                    </button>
                    <button
                      className="datepicker__action"
                      type="button"
                      onClick={() => {
                        setCalendarVisibility(!calendarVisibility);
                      }}
                    >
                      Done
                    </button>
                  </div>
                )}
              />
            </div>
          </div>
        </div>
        <div className="searchFilterMobile__filter">
          <CalendarTodayOutlinedIcon onClick={() => setCalendarVisibility(!calendarVisibility)} />
          <div role="button" className="searchFilterMobile__date" onClick={() => setCalendarVisibility(!calendarVisibility)}>
            <h5>Check-Out</h5>
            <h4>{moment(formData.checkOutDate).format('D MMM')}</h4>
            <p>{moment(formData.checkOutDate).format('ddd, YYYY')}</p>
          </div>
        </div>
      </div>
      <div className="searchFilterMobile__filter">
        <PersonOutlineOutlinedIcon onClick={() => setRoomsPopupVisibility(!roomsPopupVisibility)} />
        <div role="button" className="searchFilterMobile__rooms" onClick={() => setRoomsPopupVisibility(!roomsPopupVisibility)}>
          <h5>Rooms & Guests</h5>
          <h4>
            {formData.adults}
            {' '}
            {formData.adults === 1 ? 'Adult' : 'Adults'}
            {' '}
            {formData.kids !== 0 && (
              <>
                &
                {' '}
                {formData.kids}
                {' '}
                Children
              </>
            )}
          </h4>
        </div>
        <RoomsPopup adults={formData.adults} kids={formData.kids} handleChange={handleChange} roomsPopupVisibility={roomsPopupVisibility} setRoomsPopupVisibility={setRoomsPopupVisibility} />
      </div>
      <h5>PRICE PER NIGHT</h5>
      <div className="searchFilterMobile__prices">
        <div role="button" className={isLowerRange ? 'searchFilterMobile__priceSelected searchFilterMobile__price' : 'searchFilterMobile__price'} onClick={setLowerPriceRange}>
          <p>₹0- ₹1500</p>
        </div>
        <div role="button" className={isMediumLowerRange ? 'searchFilterMobile__priceSelected searchFilterMobile__price' : 'searchFilterMobile__price'} onClick={setMediumLowerPriceRange}>
          <p>₹1500- ₹2500</p>
        </div>
        <div role="button" className={isMediumHigherRange ? 'searchFilterMobile__priceSelected searchFilterMobile__price' : 'searchFilterMobile__price'} onClick={setMediumHigherPriceRange}>
          <p>₹2500- ₹5000</p>
        </div>
        <div role="button" className={isHigherRange ? 'searchFilterMobile__priceSelected searchFilterMobile__price' : 'searchFilterMobile__price'} onClick={setHigherPriceRange}>
          <p>₹5000+</p>
        </div>
      </div>
      <button className="searchFilterMobile__searchbtn" type="submit" onClick={handleSubmit}>Search</button>
    </div>
  );
}

export default SearchFilterMobile;
