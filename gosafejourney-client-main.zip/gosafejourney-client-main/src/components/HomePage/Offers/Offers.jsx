import React from 'react';
import Slider from 'react-slick';
import OfferCard from '../OfferCard/OfferCard';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import offer1 from '../../../images/offer1.png';
import offer2 from '../../../images/offer2.png';
import offer3 from '../../../images/offer3.png';
import './Offers.scss';

function Offers() {
  const settings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 3,
    initialSlide: 0,
    arrows: true,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
          infinite: true,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true,
          arrows: false,
          dots: true,
        },
      },
    ],
  };

  return (
    <div className="offers">
      <div className="offers__content">
        <h2>Offers</h2>
        <p>Promotions, deals and special offers for you</p>
        <Slider {...settings}>
          <OfferCard image={offer1} />
          <OfferCard image={offer2} />
          <OfferCard image={offer3} />
          <OfferCard image={offer1} />
          <OfferCard image={offer2} />
          <OfferCard image={offer3} />
          <OfferCard image={offer1} />
          <OfferCard image={offer2} />
          <OfferCard image={offer3} />
        </Slider>
      </div>
    </div>
  );
}

export default Offers;
