import React from 'react';
import LoginDetails from '../LoginDetails/LoginDetails';
import ProfileInfo from '../ProfileInfo/ProfileInfo';
import ProfileVerificationHeader from '../ProfileVerificationHeader/ProfileVerificationHeader';
import './ProfileDetailsRight.scss';

function ProfileDetailsRight() {
  const { result } = JSON.parse(localStorage.getItem('profile'));

  return (
    <div className="ProfileDetailsRight">
      <ProfileVerificationHeader />
      <ProfileInfo />
      <LoginDetails mobileNo={result?.phone} email={result?.email} />
    </div>
  );
}

export default ProfileDetailsRight;
