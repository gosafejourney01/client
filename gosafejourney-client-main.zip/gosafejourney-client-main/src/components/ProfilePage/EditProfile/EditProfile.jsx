/* eslint-disable no-unused-vars */
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { Dialog } from '@mui/material';
import Input from '../../Input/Input';
import './EditProfile.scss';
import { update } from '../../../actions/auth';

function EditProfile({
  open, setOpen, profile,
}) {
  const dispatch = useDispatch();

  const handleClose = () => setOpen(false);
  const [formData, setFormData] = useState({});

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const { _id } = profile;
    if (Object.entries(formData).length !== 0) {
      dispatch(update(_id, formData));
    }
    handleClose(true);
  };
  return (
    <Dialog
      open={open}
      onClose={handleClose}
    >
      <div className="editProfile">
        <div className="editProfile__head">
          <h3>Edit Profile</h3>
        </div>
        <div className="editProfile__content">
          <div className="editProfile__details">
            <div className="editProfile__details__row">
              <div className="editProfile__details__query">
                <p>
                  Full Name
                  <span>*</span>
                </p>
                <Input name="fullName" label="Full Name" handleChange={handleChange} defaultValue={profile.fullName ? profile.fullName : ''} />
              </div>
              <div className="editProfile__details__query">
                <p>
                  Birthday
                </p>
                <Input name="birthDate" label="Date" type="date" id="date" handleChange={handleChange} defaultValue={profile.birthDate ? profile.birthDate : ''} />
              </div>
            </div>
            <div className="editProfile__details__row">
              <div className="editProfile__details__query">
                <p>
                  Gender
                </p>
                <select name="gender" onChange={handleChange} defaultValue={profile.gender ? profile.gender : ''}>
                  <option value="">Select</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Others">Others</option>
                </select>
              </div>
              <div className="editProfile__details__query">
                <p>
                  Marital Status
                </p>
                <select name="maritialStatus" onChange={handleChange} defaultValue={profile.maritialStatus ? profile.maritialStatus : ''}>
                  <option value="">Select</option>
                  <option value="Married">Married</option>
                  <option value="Unmarried">Unmarried</option>
                  <option value="Divorced">Divorced</option>
                </select>
              </div>
            </div>
          </div>
          <div className="editProfile__buttons">
            <button type="button" className="editProfile__cancelbtn" onClick={handleClose}>Cancel</button>
            <button type="button" className="editProfile__savebtn" onClick={handleSubmit}>Save</button>
          </div>
        </div>
      </div>
    </Dialog>

  );
}

export default EditProfile;
