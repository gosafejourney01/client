import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './SideProfile.scss';
// import Person2Icon from '@mui/icons-material/Person2';
import LogoutIcon from '@mui/icons-material/Logout';

function SideProfile() {
  const [details, setDetails] = useState({});
  const navigate = useNavigate();
  const getDetails = () => {
    const data = JSON.parse(localStorage.getItem('profile'));
    setDetails(data.result);
  };

  const handleLogout = () => {
    localStorage.clear();
    navigate('/');
    window.location.reload();
  };

  useEffect(() => {
    getDetails();
  }, []);
  return (
    <div className="sideProfile">
      <div className="sideProfile__content">
        <div className="sideProfile__top">
          <h1>{details?.firstName?.charAt(0)}</h1>
        </div>
        <div className="sideProfile__bottom">
          <div className="sideProfile__name">
            <h4>{details?.fullName}</h4>
            <h6>Personal Profile</h6>
          </div>
          {/* <div className="sideProfile__profile">
            <Person2Icon />
            <h6>Profile Details</h6>
          </div> */}
          <div className="sideProfile__logout" onClick={handleLogout}>
            <LogoutIcon />
            <h6>Logout</h6>
          </div>
        </div>
      </div>
    </div>
  );
}

export default SideProfile;
