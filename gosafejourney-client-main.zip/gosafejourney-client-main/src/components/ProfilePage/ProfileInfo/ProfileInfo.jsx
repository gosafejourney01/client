/* eslint-disable no-unused-vars */
import React, { useState } from 'react';
import moment from 'moment';
import EditIcon from '@mui/icons-material/Edit';
import AddIcon from '@mui/icons-material/Add';
import './ProfileInfo.scss';
import EditProfile from '../EditProfile/EditProfile';

function ProfileInfo() {
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);

  const { result } = JSON.parse(localStorage.getItem('profile'));

  return (
    <div className="profileInfo">
      <div className="profileInfo__content">
        <div className="profileInfo__contenthead">
          <div className="profileInfo__profile">
            <h4>Profile</h4>
          </div>
          <div onClick={handleOpen} className="profileInfo__edit">
            <EditIcon />
            <h6>Edit</h6>
          </div>
        </div>
        <div className="profileInfo__seperator" />
        <div className="profileInfo__name">
          <div className="profileInfo__fields__content">
            <h6>Name</h6>
            <p>{result.fullName}</p>
          </div>
        </div>
        <div className="profileInfo__seperator" />
        <div className="profileInfo__fields">
          <div className="profileInfo__fields__content">
            <h6>Birthday</h6>
            {result.birthDate !== undefined ? (
              <div>
                <p>{moment(result.birthDate).format('MMM Do YY')}</p>
              </div>
            )
              : (
                <div onClick={handleOpen} className="profileInfo__add">
                  <AddIcon />
                  <h6>ADD</h6>
                </div>
              )}
          </div>
        </div>
        <div className="profileInfo__seperator" />
        <div className="profileInfo__fields">
          <div className="profileInfo__fields__content">
            <h6>Gender</h6>
            {result.gender !== undefined ? (
              <div>
                <p>{result.gender}</p>
              </div>
            )
              : (
                <div onClick={handleOpen} className="profileInfo__add">
                  <AddIcon />
                  <h6>ADD</h6>
                </div>
              )}
          </div>
        </div>
        <div className="profileInfo__seperator" />
        <div className="profileInfo__fields">
          <div className="profileInfo__fields__content">
            <h6>Marital Status</h6>
            {result.maritialStatus !== undefined ? (
              <div>
                <p>{result.maritialStatus}</p>
              </div>
            )
              : (
                <div onClick={handleOpen} className="profileInfo__add">
                  <AddIcon />
                  <h6>ADD</h6>
                </div>
              )}
          </div>
        </div>
      </div>
      <EditProfile open={open} setOpen={setOpen} profile={result} />
    </div>
  );
}

export default ProfileInfo;
