import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import PropertyRoomCard from '../PropertyRoomCard/PropertyRoomCard';
import './PropertyRooms.scss';
import getRooms from '../../../actions/room';

function PropertyRooms({ currentPropertyRoom, formData, currentProperty }) {
  const rooms = useSelector((state) => state.room.roomData);
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getRooms({ roomId: currentPropertyRoom }));
  }, []);
  return (
    <div id="propertyDetails__rooms" className="propertyRooms">
      <h2>Select Rooms</h2>
      <div className="propertyRooms__table">
        <div className="propertyRooms__tablehead">
          <div className="propertyRooms__head">
            {rooms?.length <= 1 ? (
              <span className="propertyRooms__headRoomType">{`${rooms?.length} Room Type`}</span>)
              : (
                <span className="propertyRooms__headRoomType">{`${rooms?.length} Room Types`}</span>
              )}
            <KeyboardArrowDownIcon className="propertyRooms__headRoomType" />
          </div>
          <div className="propertyRooms__separator" />
          <div className="propertyRooms__head">
            <span>OPTIONS</span>
          </div>
          <div className="propertyRooms__separator" />
          <div className="propertyRooms__head">
            <span>PRICE</span>
          </div>
        </div>
        {rooms?.length === 0 ? <>Loading</> : rooms?.map((room) => (
          <div className="propertyRooms__row">
            <PropertyRoomCard room={room} formData={formData} currentPropertyRoom={currentPropertyRoom} currentProperty={currentProperty} propertyImages={room?.images} key={room?.createdAt} />
            <div className="propertyRooms__rowSeparator" />
          </div>
        ))}
      </div>
    </div>
  );
}

export default PropertyRooms;
