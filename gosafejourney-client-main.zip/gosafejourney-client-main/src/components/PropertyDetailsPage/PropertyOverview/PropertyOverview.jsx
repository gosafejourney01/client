import React, { useState } from 'react';
// import { Avatar } from '@mui/material';
// import AccessTimeIcon from '@mui/icons-material/AccessTime';
// import TranslateIcon from '@mui/icons-material/Translate';
import './PropertyOverview.scss';
import moment from 'moment/moment';

function ReadMore({ children }) {
  const text = children;
  const [isReadMore, setIsReadMore] = useState(true);
  const toggleReadMore = () => {
    setIsReadMore(!isReadMore);
  };
  return (
    <p className="propertyOverview__about">
      {isReadMore ? text?.slice(0, 250) : text}
      <span onClick={toggleReadMore} className="read-or-hide">
        {isReadMore ? '...Read More' : ' Show Less'}
      </span>
    </p>
  );
}

function PropertyOverview({ currentProperty }) {
  return (
    <div id="propertyDetails__overview" className="propertyOverview">
      <div className="propertyOverview__content">
        <h2>About the Homestay</h2>
        <span>
          CHECK IN&nbsp;
          {moment(currentProperty?.checkInDate).format('D MMM, YYYY')}
          &nbsp;• CHECK OUT&nbsp;
          {moment(currentProperty?.checkOutDate).format('D MMM, YYYY')}
        </span>
        <ReadMore>
          {currentProperty?.about}
        </ReadMore>
        {/* <hr />
        <h2>Property Managed and Hosted by Hasrat</h2>
        <div className="propertyOverview__host">
          <Avatar>H</Avatar>
          <div className="propertyOverview__hostDetails">
            <div className="propertyOverview__hostInfo">
              <div className="propertyOverview__hostDetail">
                <AccessTimeIcon />
                <p>Hosting since 2020</p>
              </div>
              <div className="propertyOverview__hostDetail">
                <TranslateIcon />
                <p>English,Punjabi,Hindi</p>
              </div>
            </div>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos..
              <span>Read More</span>
            </p>
          </div>
        </div> */}
      </div>
    </div>
  );
}

export default PropertyOverview;
