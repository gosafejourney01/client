import React, { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import ImageViewer from 'react-simple-image-viewer';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
// import { Link } from 'react-router-dom';
import KingBedIcon from '@mui/icons-material/KingBed';
import RoomDetailsModal from '../../RoomDetailsModal/RoomDetailsModal';
import Auth from '../../Auth/Auth';
import cancel2 from '../../../images/cancel_2.svg';
import available1 from '../../../images/available_1.svg';
import './PropertyRoomCard.scss';

function PropertyRoomCard({
  room, currentPropertyRoom, propertyImages, formData, currentProperty,
}) {
  const [currentImage, setCurrentImage] = useState(0);
  const [isViewerOpen, setIsViewerOpen] = useState(false);
  const [open, setOpen] = useState(false);
  // const handleOpen = () => setOpen(true);
  const [loginOpen, setLoginOpen] = useState(false);
  const handleLoginOpen = () => setLoginOpen(true);
  const navigate = useNavigate();
  const settings = {
    dots: false,
    infinite: false,
    speed: 0,
    slidesToShow: 1,
    slidesToScroll: 1,
    initialSlide: 0,
    arrows: true,
  };

  const openImageViewer = useCallback((index) => {
    setCurrentImage(index);
    setIsViewerOpen(true);
  }, []);

  const closeImageViewer = () => {
    setCurrentImage(0);
    setIsViewerOpen(false);
  };
  const getTax = (val) => {
    const tax = (28 * val) / 100;
    return tax;
  };
  const handleClick = (e) => {
    e.cancelBubble = true;
    if (e.stopPropagation) e.stopPropagation();
    navigate('/booking', { state: { formData, currentProperty, room } });
  };

  return (
    <div className="propertyRoomCard">
      <div className="propertyRoomCard__roomDetail">
        <Slider {...settings} className="propertyRoomCard__roomSlider">
          {propertyImages.map((image, index) => (
            <img className="propertyRoomCard__roomimg" src={image} onClick={() => openImageViewer(index)} alt="triple room" />
          ))}
        </Slider>
        <h3 className="propertyRoomCard__roomname">{room?.roomName}</h3>
        <div className="propertyRoomCard__roomFeature">
          <KingBedIcon className="propertyRoomCard__roombed" />
          <p>{`${room?.bedDetails[0]?.noBeds} ${room?.bedDetails[0]?.bedType} Beds`}</p>
        </div>
        <div className="propertyRoomCard__roomFeature">
          <p>{room?.smoking}</p>
        </div>
        <div className="propertyRoomCard__roomFeature">
          <p>{`${room?.noGuestsInRoom} guests per room`}</p>
        </div>
      </div>
      <div className="propertyRoomCard__separator" />
      <div className="propertyRoomCard__roomDetail">
        <h3>Room Only</h3>
        <div className="propertyRoomCard__roomFeature">
          <img src={cancel2} alt="non-refundable" />
          <p>Non-Refundable</p>
        </div>
        {currentPropertyRoom?.arePetsAllowed ? (
          <div className="propertyRoomCard__roomFeature">
            <img src={available1} alt="Pets are allowed" />
            <p>Pets are allowed</p>
          </div>
        )
          : (
            <div className="propertyRoomCard__roomFeature">
              <img src={cancel2} alt="Pets are not allowed" />
              <p>Pets are not allowed</p>
            </div>
          )}
        {currentPropertyRoom?.isBreakfastProvided ? (
          <div className="propertyRoomCard__roomFeature">
            <img src={available1} alt="meals included" />
            <p>Meals Included</p>
          </div>
        )
          : (
            <div className="propertyRoomCard__roomFeature">
              <img src={cancel2} alt="meals not included" />
              <p>Meals Not Included</p>
            </div>
          )}
        {currentPropertyRoom?.arePartiesAllowed ? (
          <div className="propertyRoomCard__roomFeature">
            <img src={available1} alt="Parties are allowed" />
            <p>Parties are allowed</p>
          </div>
        )
          : (
            <div className="propertyRoomCard__roomFeature">
              <img src={cancel2} alt="Parties are not allowed" />
              <p>Parties are not allowed</p>
            </div>
          )}
        {/* <span onClick={ handleOpen }>More Details</span> */}
      </div>
      <div className="propertyRoomCard__separator" />
      <div className="propertyRoomCard__roomDetail">
        <s>{`₹ ${room.price + (5 * (room.price / 100))} `}</s>
        <h3>{`₹ ${room.price}`}</h3>
        <p>{`+ ₹ ${getTax(room.price)} taxes & fees`}</p>
        <p>Per Night</p>
        {localStorage.getItem('profile') === undefined && <span onClick={handleLoginOpen}>{`To get this @ ₹ ${room.price} Login Now `}</span>}
        {/* <Link to="/booking"><button className="propertyRoomCard__selectbtn" type="button">Select Room</button></Link> */}
        <button className="propertyRoomCard__selectbtn" onClick={handleClick} type="button">Select Room</button>
      </div>
      <RoomDetailsModal open={open} setOpen={setOpen} />
      <Auth open={loginOpen} setOpen={setLoginOpen} />
      {isViewerOpen && (
        <ImageViewer
          src={propertyImages}
          currentIndex={currentImage}
          disableScroll={false}
          closeOnClickOutside
          onClose={closeImageViewer}
        />
      )}
    </div>
  );
}

export default PropertyRoomCard;
