import React from 'react';
// import PropertyRuleCard from '../PropertyRuleCard/PropertyRuleCard';
import './PropertyRules.scss';

function PropertyRules() {
  const propertyRules = [
    'Guests with fever are not allowed',
    'Guests from containment zones are not allowed',
    'Non-Govt IDs is not accepted as ID proof(s)',
    'Govt. ID, Passport, Aadhar and Driving License are accepted as ID proof(s)',
    'Property staff is trained on hygiene guidelines',
    'Pets are not allowed.',
    'Outside food is not allowed',
    'Allows private parties or events',
    'Quarantine protocols are being followed as per local government authorities',
    'Fee for buffet breakfast: INR 2200 for adults and INR 1100 for children (approximately)|Early check-in is available for a fee (subject to availability)|Late check-out is available for a fee (subject to availability)',
    'Extra-person charges may apply and vary depending on property policy|Government-issued photo identification and a credit card, debit card, or cash deposit may be required at check-in for incidental charges.',
  ];

  const hygieneRules = [
    'Quarantine protocols are being followed as per local government authorities',
    'Guests from containment zones are not allowed',
    'Shared resources in common areas are properly sanitized',
    'Property staff is trained on hygiene guidelines',
    'Guests with fever are not allowed',
    'Guests without Aarogya Set app are allowed',
    'Hand sanitizer is provided in guest accommodation and common areas',
  ];

  const guestProfile = [
    'Unmarried couples allowed',
    'Bachelors allowed',
    'Guests below 18 years of age are allowed',
    'Suitable for children',
  ];

  return (
    <div id="propertyDetails__rules" className="propertyRules">
      <h2>Property Rules</h2>
      <span>CHECK IN 12:30PM • CHECK OUT 11:00 AM</span>
      {/* <PropertyRuleCard /> */}
      <div className="propertyRules__parts">
        <div className="propertyRules__part">
          <ul>
            {propertyRules.slice(0, Math.ceil(propertyRules.length / 2)).map((rule) => <li>{rule}</li>)}
          </ul>
        </div>
        <div className="propertyRules__part">
          <ul>
            {propertyRules.slice(Math.ceil(propertyRules.length / 2), propertyRules.length).map((rule) => <li>{rule}</li>)}
          </ul>
        </div>
      </div>
      <h2>
        Safety and Hygiene
        {' '}
        (
        {hygieneRules.length}
        )
      </h2>
      <div className="propertyRules__parts">
        <div className="propertyRules__part">
          <ul>
            {hygieneRules.slice(0, Math.ceil(hygieneRules.length / 2)).map((rule) => <li>{rule}</li>)}
          </ul>
        </div>
        <div className="propertyRules__part">
          <ul>
            {hygieneRules.slice(Math.ceil(hygieneRules.length / 2), hygieneRules.length).map((rule) => <li>{rule}</li>)}
          </ul>
        </div>
      </div>
      <h2>
        Guest Profile
        {' '}
        (
        {guestProfile.length}
        )
      </h2>
      <div className="propertyRules__parts">
        <div className="propertyRules__part">
          <ul>
            {guestProfile.slice(0, Math.ceil(guestProfile.length / 2)).map((rule) => <li>{rule}</li>)}
          </ul>
        </div>
        <div className="propertyRules__part">
          <ul>
            {guestProfile.slice(Math.ceil(guestProfile.length / 2), guestProfile.length).map((rule) => <li>{rule}</li>)}
          </ul>
        </div>
      </div>
    </div>
  );
}

export default PropertyRules;
