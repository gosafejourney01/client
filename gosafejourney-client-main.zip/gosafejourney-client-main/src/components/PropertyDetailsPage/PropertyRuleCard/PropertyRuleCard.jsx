import React from 'react';
import couplerule from '../../../images/couplerules.svg';
import './PropertyRuleCard.scss';

function PropertyRuleCard() {
  return (
    <div className="propertyRuleCard">
      <div className="propertyRuleCard__img">
        <img src={couplerule} alt="couple friendly" />
      </div>
      <div className="propertyRuleCard__content">
        <div className="propertyRuleCard__head">
          <h3> Couple Bachelor Rules</h3>
          <p>Couple Friendly</p>
        </div>
        <span>Unmarried Guests/Couple with IDs are Allowed</span>
      </div>
    </div>
  );
}

export default PropertyRuleCard;
