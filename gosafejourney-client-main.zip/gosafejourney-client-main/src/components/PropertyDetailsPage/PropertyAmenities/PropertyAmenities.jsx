import React from 'react';
import caretaker from '../../../images/amenities_caretaker.svg';
import power from '../../../images/amenities_power.svg';
import tours from '../../../images/amenities_tours.svg';
import housekeeping from '../../../images/amenities_housekeeping.svg';
import ac from '../../../images/amenities_ac.svg';
import restaurant from '../../../images/amenities_restaurant.svg';
import './PropertyAmenities.scss';

function PropertyAmenities() {
  return (
    <div id="propertyDetails__amenities" className="propertyAmenities">
      <h2>Amenities at Hotel Candolim Aloft</h2>
      <div className="propertyAmenities__amenities">
        <div className="propertyAmenities__amenity">
          <img src={caretaker} alt="caretaker" />
          <p>Caretaker</p>
        </div>
        <div className="propertyAmenities__amenity">
          <img src={power} alt="power backup" />
          <p>Power Backup</p>
        </div>
        <div className="propertyAmenities__amenity">
          <img src={tours} alt="tours" />
          <p>Tours & Treks</p>
        </div>
        <div className="propertyAmenities__amenity">
          <img src={housekeeping} alt="housekeeping" />
          <p>House Keeping</p>
        </div>
        <div className="propertyAmenities__amenity">
          <img src={ac} alt="ac" />
          <p>Air Condition</p>
        </div>
        <div className="propertyAmenities__amenity">
          <img src={restaurant} alt="restaurant" />
          <p>Restaurant</p>
        </div>
      </div>
      <hr />
      <button type="button">View All 42 Amenities</button>
    </div>
  );
}

export default PropertyAmenities;
