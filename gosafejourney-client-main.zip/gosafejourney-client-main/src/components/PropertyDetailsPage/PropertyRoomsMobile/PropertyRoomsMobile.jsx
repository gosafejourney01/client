import React from 'react';
import Slider from 'react-slick';
import PropertyRoomCardMobile from '../PropertyRoomCardMobile/PropertyRoomCardMobile';
import roomtype1 from '../../../images/roomtype1.png';
import roomtype2 from '../../../images/roomtype2.png';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import './PropertyRoomsMobile.scss';

function PropertyRoomsMobile() {
  const propertyImages1 = [roomtype1, roomtype2];
  const propertyImages2 = [roomtype2, roomtype1];
  const settings = {
    dots: false,
    infinite: true,
    speed: 0,
    slidesToShow: 3,
    slidesToScroll: 3,
    initialSlide: 0,
    arrows: true,
    responsive: [
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true,
          arrows: false,
          dots: true,
        },
      },
    ],
  };

  return (
    <div className="propertyRoomsMobile">
      <h2>Select Rooms</h2>
      <Slider {...settings}>
        <PropertyRoomCardMobile propertyImages={propertyImages1} />
        <PropertyRoomCardMobile propertyImages={propertyImages2} />
        <PropertyRoomCardMobile propertyImages={propertyImages1} />
        <PropertyRoomCardMobile propertyImages={propertyImages2} />
      </Slider>
    </div>
  );
}

export default PropertyRoomsMobile;
