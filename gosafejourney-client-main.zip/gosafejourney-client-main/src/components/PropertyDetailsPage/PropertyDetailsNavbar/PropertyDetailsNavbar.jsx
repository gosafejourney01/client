import React from 'react';
import { Link } from 'react-scroll';
import './PropertyDetailsNavbar.scss';

function PropertyDetailsNavbar() {
  return (
    <div className="propertyDetailsNavbar">
      <div className="propertyDetailsNavbar__content">
        <Link
          activeClass="active"
          to="propertyDetails__overview"
          spy
          smooth
          offset={-120}
        >
          <h4>Overview</h4>
        </Link>
        <Link
          activeClass="active"
          to="propertyDetails__rooms"
          spy
          smooth
          offset={-120}
        >
          <h4>Rooms</h4>
        </Link>
        <Link
          activeClass="active"
          to="propertyDetails__location"
          spy
          smooth
          offset={-120}
        >
          <h4>Location</h4>
        </Link>
        {/* <Link
          activeClass="active"
          to="propertyDetails__amenities"
          spy
          smooth
          offset={-120}
        >
          <h4>Amenities</h4>
        </Link>
        <Link
          activeClass="active"
          to="propertyDetails__rules"
          spy
          smooth
          offset={-120}
        >
          <h4>Property Rules</h4>
        </Link> */}
        <Link
          activeClass="active"
          to="propertyDetails__reviews"
          spy
          smooth
          offset={-120}
        >
          <h4>User Reviews</h4>
        </Link>
      </div>
    </div>
  );
}

export default PropertyDetailsNavbar;
