import React from 'react';
import './PropertyLocation.scss';

function PropertyLocation() {
  return (
    <div id="propertyDetails__location" className="propertyLocation">
      <h2>Location</h2>
      <iframe title="hotel location" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3844.3681909567017!2d73.76571481474775!3d15.518380489223267!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bbfc1bb0e305fc1%3A0xae4fd906efa31579!2sHotel%20Candolim%20Aloft!5e0!3m2!1sen!2sin!4v1671734232487!5m2!1sen!2sin" height="500" style={{ border: 0, borderRadius: '8px', width: '100%' }} allowFullScreen="" loading="lazy" referrerPolicy="no-referrer-when-downgrade" />
    </div>
  );
}

export default PropertyLocation;
