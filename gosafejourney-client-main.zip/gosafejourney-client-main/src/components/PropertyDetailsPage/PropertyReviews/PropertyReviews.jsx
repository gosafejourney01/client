import React from 'react';
import PropertyReviewCard from '../PropertyReviewCard/PropertyReviewCard';
import './PropertyReviews.scss';

function PropertyReviews({ reviews }) {
  return (
    <div id="propertyDetails__reviews" className="propertyReviews">
      <h2 className="propertyReviews__head">User Ratings & Reviews</h2>
      <p>Important information that you need to know before you book!</p>
      {/* <button type="button">All Reviews</button>
      <hr />
      <h2>Featured Reviews</h2> */}
      {reviews?.map((review, index) => <PropertyReviewCard key={index} review={review} />)}
    </div>
  );
}

export default PropertyReviews;
