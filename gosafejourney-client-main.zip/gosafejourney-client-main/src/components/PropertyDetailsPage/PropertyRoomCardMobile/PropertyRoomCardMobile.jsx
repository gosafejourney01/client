import React, { useState } from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import { Link } from 'react-router-dom';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KingBedIcon from '@mui/icons-material/KingBed';
import RoomDetailsModal from '../../RoomDetailsModal/RoomDetailsModal';
import Auth from '../../Auth/Auth';
import cancel2 from '../../../images/cancel_2.svg';
import available1 from '../../../images/available_1.svg';
import './PropertyRoomCardMobile.scss';

function PropertyRoomCardMobile({ propertyImages }) {
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const [loginOpen, setLoginOpen] = useState(false);
  const handleLoginOpen = () => setLoginOpen(true);

  const settings = {
    dots: false,
    infinite: false,
    speed: 0,
    slidesToShow: 1,
    slidesToScroll: 1,
    initialSlide: 0,
    arrows: true,
  };

  return (
    <div className="propertyRoomCardMobile">
      <div className="propertyRoomCardMobile__head">
        <span className="propertyRoomCardMobile__headRoomType">2 Room Types</span>
        <KeyboardArrowDownIcon className="propertyRooms__headRoomType" />
      </div>
      <div className="propertyRoomCardMobile__roomDetail">
        <Slider {...settings} className="propertyRoomCard__roomSlider">
          {propertyImages.map((image, index) => (
            <img className="propertyRoomCard__roomimg" src={image} key={index} alt="triple room" />
          ))}
        </Slider>
        <h3 className="propertyRoomCardMobile__roomname">Triple Room</h3>
        <div className="propertyRoomCard__roomFeature">
          <KingBedIcon className="propertyRoomCard__roombed" />
          <p>Double Bed</p>
        </div>
      </div>
      <div className="propertyRoomCardMobile__head">
        <span>OPTIONS</span>
      </div>
      <div className="propertyRoomCardMobile__roomDetail">
        <h3>Room Only</h3>
        <div className="propertyRoomCard__roomFeature">
          <img src={cancel2} alt="non-refundable" />
          <p>Non-Refundable</p>
        </div>
        <div className="propertyRoomCard__roomFeature">
          <img src={available1} alt="meals included" />
          <p>Meals Included</p>
        </div>
        <span onClick={handleOpen}>More Details</span>
      </div>
      <div className="propertyRoomCardMobile__head">
        <span>PRICE</span>
      </div>
      <div className="propertyRoomCardMobile__roomDetail">
        <s>₹ 10,144</s>
        <h3>₹ 7,144</h3>
        <p>+ ₹ 1, 780 taxes & fees</p>
        <p>Per Night</p>
        <span onClick={handleLoginOpen}>To get this @ ₹ 7,144 Login Now </span>
        <Link to="/booking"><button className="propertyRoomCard__selectbtn" type="button">Select Room</button></Link>
      </div>
      <RoomDetailsModal open={open} setOpen={setOpen} />
      <Auth open={loginOpen} setOpen={setLoginOpen} />
    </div>
  );
}

export default PropertyRoomCardMobile;
