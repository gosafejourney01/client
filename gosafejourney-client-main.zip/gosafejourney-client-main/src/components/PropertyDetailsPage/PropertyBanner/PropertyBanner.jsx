import { LocationOnOutlined } from '@mui/icons-material';
import React from 'react';
import { ReactPhotoCollage } from 'react-photo-collage';
import { Link } from 'react-scroll';
// import propertyimg1 from '../../../images/hotelimg_1.png';
// import propertyimg2 from '../../../images/hotelimg_2.png';
// import propertyimg3 from '../../../images/hotelimg_3.png';
// import roomtype1 from '../../../images/roomtype1.png';
// import roomtype2 from '../../../images/roomtype2.png';
import caretaker from '../../../images/amenities_caretaker.svg';
import power from '../../../images/amenities_power.svg';
import tours from '../../../images/amenities_tours.svg';
import housekeeping from '../../../images/amenities_housekeeping.svg';
import ac from '../../../images/amenities_ac.svg';
import restaurant from '../../../images/amenities_restaurant.svg';
import './PropertyBanner.scss';
import useWindowDimensions from '../../../hooks/useWindowDimensions';

function PropertyBanner({ currentProperty }) {
  const { width } = useWindowDimensions();
  const setting = {
    width: '100%',
    height: ['270px', '200px'],
    layout: width >= 768 ? [3, 4] : width > 500 ? [2, 3] : [1, 2],
    photos: currentProperty?.propertyImages.map((img) => ({
      source: img,
    })),
    showNumOfRemainingPhotos: true,
  };

  return (
    <div className="propertyBanner">
      <div className="propertyBanner__imgs">
        <ReactPhotoCollage {...setting} />
      </div>
      <div className="propertyBanner__propertyDetails">
        <div>
          <h2 className="propertyBanner__propertyName">{currentProperty?.propertyName}</h2>
          <div className="propertyBanner__location">
            <LocationOnOutlined />
            <p>{`${currentProperty?.address} | ${currentProperty?.city}`}</p>
          </div>
        </div>
        <Link
          activeClass="active"
          to="propertyDetails__reviews"
          spy
          smooth
          offset={-120}
        >
          <div className="propertyBanner__propertyRating">
            <h2>{currentProperty?.rating}</h2>
            <div>
              <h3>Excellent</h3>
              {/* <p>(2483 verified ratings)</p> */}
              <h5>Read All Reviews</h5>
            </div>
          </div>
        </Link>
      </div>
      <h2>Popular Amenities</h2>
      <div className="propertyBanner__amenities">
        <div className="propertyBanner__amenity">
          <img src={caretaker} alt="caretaker" />
          <p>Caretaker</p>
        </div>
        <div className="propertyBanner__amenity">
          <img src={power} alt="power backup" />
          <p>Power Backup</p>
        </div>
        <div className="propertyBanner__amenity">
          <img src={tours} alt="tours" />
          <p>Tours & Treks</p>
        </div>
        <div className="propertyBanner__amenity">
          <img src={housekeeping} alt="housekeeping" />
          <p>House Keeping</p>
        </div>
        <div className="propertyBanner__amenity">
          <img src={ac} alt="ac" />
          <p>Air Condition</p>
        </div>
        <div className="propertyBanner__amenity">
          <img src={restaurant} alt="restaurant" />
          <p>Restaurant</p>
        </div>
        <Link
          activeClass="active"
          to="propertyDetails__amenities"
          spy
          smooth
          offset={-120}
        >
          <div className="propertyBanner__moreAmenities">
            <h2>+42</h2>
            <p>More Amenities</p>
          </div>
        </Link>
      </div>
    </div>
  );
}

export default PropertyBanner;
