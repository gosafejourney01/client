import React from 'react';
import './PropertyReviewCard.scss';

function PropertyReviewCard({ review }) {
  return (
    <div className="propertyReviewCard">
      <h3>{review?.reviewer?.fullName}</h3>
      <p className="propertyReviews__reviewer">
        rated
        {' '}
        <span>
          {review?.rating}
          &nbsp;star
        </span>
      </p>
      <p>{review?.feedback}</p>
    </div>
  );
}

export default PropertyReviewCard;
