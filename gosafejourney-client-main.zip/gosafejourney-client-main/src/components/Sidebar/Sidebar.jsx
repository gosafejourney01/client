import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { IconButton } from '@mui/material';
import { CloseRounded, Logout } from '@mui/icons-material';
import logo from '../../images/logo.png';
import './Sidebar.scss';

function Sidebar() {
  const navigate = useNavigate();
  const closeMenu = () => {
    document.getElementById('sidebar').style.left = '-110%';
  };

  const handleLogout = () => {
    localStorage.clear();
    navigate('/');
    window.location.reload();
  };

  return (
    <div id="sidebar" className="sidebar">
      <div className="sidebar__head">
        <img src={logo} alt="gosafejourney logo" />
        <IconButton onClick={closeMenu}>
          <CloseRounded />
        </IconButton>
      </div>
      <div className="sidebar__content">
        <Link to="/">
          <p>Home</p>
        </Link>
        <a
          href={process.env.REACT_APP_PARTNER_URL}
          target="_blank"
          rel="noopener noreferrer"
        >
          <p>List Your Property</p>
        </a>
      </div>
      <div className="sidebar__logout" onClick={closeMenu}>
        <IconButton>
          <Logout />
        </IconButton>
        <p onClick={handleLogout}>Sign Out</p>
      </div>
    </div>
  );
}

export default Sidebar;
