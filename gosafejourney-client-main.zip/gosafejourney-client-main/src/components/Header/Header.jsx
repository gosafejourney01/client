import React, { useEffect, useState } from 'react';
import {
  Link, NavLink, useLocation, useNavigate,
} from 'react-router-dom';
import { useDispatch } from 'react-redux';
import decode from 'jwt-decode';
import MenuIcon from '@mui/icons-material/Menu';
import LoginIcon from '@mui/icons-material/Login';
import {
  Avatar,
  IconButton,
  ListItemIcon,
  Menu,
  MenuItem,
} from '@mui/material';
import { Logout } from '@mui/icons-material';
import { LOGOUT } from '../../constants/actionTypes';
import Auth from '../Auth/Auth';
import Sidebar from '../Sidebar/Sidebar';
import logo from '../../images/logo.png';
import logodark from '../../images/logodark.svg';
import { ReactComponent as MyProfileIcon } from '../../images/myProfileIcon.svg';
import { ReactComponent as MyBookingsIcon } from '../../images/myBookingsIcon.svg';
import './Header.scss';

function Header() {
  const [openAuth, setOpenAuth] = useState(false);
  const handleOpen = () => setOpenAuth(true);
  const location = useLocation();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [user, setUser] = useState(JSON.parse(localStorage.getItem('profile')));
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const logout = () => {
    dispatch({ type: LOGOUT });
    navigate('/');
    setUser(null);
  };

  useEffect(() => {
    const token = user?.token;
    if (token) {
      const decodedToken = decode(token);

      if (decodedToken.exp * 1000 < new Date().getTime()) logout();
    }
    setUser(JSON.parse(localStorage.getItem('profile')));
    // eslint-disable-next-line
  }, [location]);

  const openMenu = () => {
    document.getElementById('sidebar').style.left = '-8px';
  };

  return (
    <div className={location.pathname !== '/' ? 'header' : 'header__home'}>
      <div className="header__content">
        <MenuIcon className="header__mobileMenu" onClick={openMenu} />
        <div className="header__logo">
          <NavLink to="/">
            <img
              src={location.pathname !== '/' ? logodark : logo}
              alt="gosafejourney logo"
            />
          </NavLink>
        </div>
        <div className="header__menu">
          <Link to="/">
            <h5>Home</h5>
          </Link>
          <a
            href={process.env.REACT_APP_PARTNER_URL}
            target="_blank"
            rel="noopener noreferrer"
          >
            <h5>List Your Property</h5>
          </a>
        </div>
        {user ? (
          <IconButton
            onClick={handleClick}
            size="small"
            sx={{ ml: 2 }}
            aria-controls={open ? 'account-menu' : undefined}
            aria-haspopup="true"
            aria-expanded={open ? 'true' : undefined}
          >
            <Avatar
              className="header__profile"
              // eslint-disable-next-line no-useless-concat
              src={'https://ui-avatars.com/api/?background=random&name=' + `${user.result.fullName}`}
              alt={user.result.fullName}
            >
              {user.result.fullName[0]}
            </Avatar>
          </IconButton>
        ) : (
          <div
            className={
              location.pathname !== '/'
                ? 'header__profile'
                : 'header__profilehome'
            }
            onClick={handleOpen}
          >
            <LoginIcon className="header__loginIcon" />
            <button type="button">Login/Signup</button>
          </div>
        )}
      </div>
      <Auth open={openAuth} setOpen={setOpenAuth} />
      <Sidebar />
      <Menu
        className="header__muiMenu"
        anchorEl={anchorEl}
        id="account-menu"
        open={open}
        onClose={handleClose}
        onClick={handleClose}
        PaperProps={{
          elevation: 0,
          sx: {
            overflow: 'visible',
            filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
            mt: 1.5,
            '& .MuiAvatar-root': {
              width: 26,
              height: 26,
              mr: 1,
            },
            '&:before': {
              content: '""',
              display: 'block',
              position: 'absolute',
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: 'background.paper',
              transform: 'translateY(-50%) rotate(45deg)',
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: 'right', vertical: 'top' }}
        anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
      >
        <MenuItem onClick={() => navigate('/profile')}>
          <ListItemIcon>
            <MyProfileIcon />
          </ListItemIcon>
          <div className="header__profileMenu">
            <p>My Profile</p>
            <span>Manage your profile, traveller details,</span>
            <span>login details and password</span>
          </div>
        </MenuItem>
        <MenuItem onClick={() => navigate('/mybooking')}>
          <ListItemIcon>
            <MyBookingsIcon />
          </ListItemIcon>
          <div className="header__profileMenu">
            <p>My Bookings</p>
            <span>See booking details, print e-ticket,</span>
            <span>Cancel booking, Modify Booking</span>
          </div>
        </MenuItem>
        <MenuItem onClick={logout}>
          <ListItemIcon>
            <Logout fontSize="medium" />
          </ListItemIcon>
          <div className="header__profileMenu">
            <p>Logout</p>
          </div>
        </MenuItem>
      </Menu>
    </div>
  );
}

export default Header;
