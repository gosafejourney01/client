import React from 'react';
import { useDispatch } from 'react-redux';
import { Dialog, Rating } from '@mui/material';
import StarBorderRoundedIcon from '@mui/icons-material/StarBorderRounded';
import StarRoundedIcon from '@mui/icons-material/StarRounded';
import { addReview } from '../../actions/booking';
import './LeaveReviewModal.scss';

function LeaveReviewModal({ open, setOpen, bookingId }) {
  const InitialState = {
    rating: 5,
    feedback: '',
  };
  const [formData, setFormData] = React.useState(InitialState);
  const dispatch = useDispatch();

  const handleClose = () => setOpen(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = () => {
    /* setOpen(false); */
    dispatch(addReview(bookingId, formData));
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
    >
      <div className="leaveReviewModal">
        <div className="leaveReviewModal__head">
          <h3>Your opinion matters to us!</h3>
        </div>
        <div className="leaveReviewModal__content">
          <h5>How was quality of the hotel?</h5>
          <div className="leaveReviewModal__stars">
            <Rating
              name="rating"
              onChange={handleChange}
              defaultValue={formData.rating}
              size="large"
              precision={0.5}
              icon={<StarRoundedIcon fontSize="inherit" />}
              emptyIcon={<StarBorderRoundedIcon fontSize="inherit" />}
            />
          </div>
          <textarea name="feedback" placeholder="Leave a message, if you want :)" defaultValue={formData.feedback} onChange={handleChange} />
          <button type="button" onClick={() => handleSubmit()}>Rate Now</button>
        </div>
        <div className="leaveReviewModal__foot" onClick={() => handleClose()}>
          <h5>Maybe Later</h5>
        </div>
      </div>
    </Dialog>
  );
}

export default LeaveReviewModal;
