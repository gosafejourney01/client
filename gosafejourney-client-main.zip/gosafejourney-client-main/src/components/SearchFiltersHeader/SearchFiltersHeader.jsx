import React, { useState, useEffect } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import SearchIcon from '@mui/icons-material/Search';
import moment from 'moment/moment';
import { Calendar, utils } from '@amir04lm26/react-modern-calendar-date-picker';
import { useDispatch } from 'react-redux';
import RoomsPopup from '../RoomsPopup/RoomsPopup';
import './SearchFiltersHeader.scss';
import getProperties from '../../actions/property';

function SearchFiltersHeader({
  formData, handleChange, handleCheckInCheckOutChange, setFormData,
}) {
  const location = useLocation();

  const [calendarVisibility, setCalendarVisibility] = useState(false);
  const [roomsPopupVisibility, setRoomsPopupVisibility] = useState(false);

  const defaultFrom = {
    year: formData.checkInDate.getFullYear(),
    month: formData.checkInDate.getMonth() + 1,
    day: formData.checkInDate.getDate(),
  };

  const defaultTo = {
    year: formData.checkOutDate.getFullYear(),
    month: formData.checkOutDate.getMonth() + 1,
    day: formData.checkOutDate.getDate(),
  };

  const [selectedDayRange, setSelectedDayRange] = useState({
    from: defaultFrom,
    to: defaultTo,
  });

  const handleLocationChange = (e) => {
    setFormData({ ...formData, location: e.target.value });
  };

  const dispatch = useDispatch();
  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(getProperties(formData, () => { Navigate('/property-search'); }));
  };

  console.log('form data', formData);

  useEffect(() => {
    if (selectedDayRange.from !== null && selectedDayRange.to !== null) {
      handleCheckInCheckOutChange(new Date(selectedDayRange.from.year, selectedDayRange.from.month - 1, selectedDayRange.from.day), new Date(selectedDayRange.to.year, selectedDayRange.to.month - 1, selectedDayRange.to.day));
    }
  }, [selectedDayRange]);

  return (
    <div className="search__results">
      <div className="search__result">
        <div className="search_resultcontent">
          <div className="search__answer">
            <div className="search__query">
              <h6> City, area or property </h6>
            </div>
            <div>
              <p>{(formData.location === undefined || formData.location === '') ? formData?.location : 'No city is selected'}</p>
            </div>
          </div>
          <div className="search__answer">
            <div className="search__query" onClick={() => setCalendarVisibility(!calendarVisibility)}>
              <h6> Check-In </h6>
              <KeyboardArrowDownIcon />
            </div>
            <div className="datepicker">
              <div className="datepicker__content" style={{ display: !calendarVisibility && 'none' }}>
                <Calendar
                  calendarClassName="responsive-calendar"
                  value={selectedDayRange}
                  onChange={setSelectedDayRange}
                  shouldHighlightWeekends
                  minimumDate={utils().getToday()}
                  colorPrimary="#0fbcf9"
                  colorPrimaryLight="rgba(75, 207, 250, 0.4)"
                  renderFooter={() => (
                    <div className="datepicker__buttons">
                      <button
                        className="datepicker__action"
                        type="button"
                        onClick={() => {
                          setSelectedDayRange({ from: null, to: null });
                        }}
                      >
                        Reset
                      </button>
                      <button
                        className="datepicker__action"
                        type="button"
                        onClick={() => {
                          setCalendarVisibility(!calendarVisibility);
                        }}
                      >
                        Done
                      </button>
                    </div>
                  )}
                />
              </div>
            </div>
            <p>{moment(formData.checkInDate).format('D MMM, YYYY')}</p>
          </div>
          <div className="search__answer">
            <div className="search__query" onClick={() => setCalendarVisibility(!calendarVisibility)}>
              <h6> Check-Out </h6>
              <KeyboardArrowDownIcon />
            </div>
            <p>
              {moment(formData.checkOutDate).format('D MMM, YYYY')}
            </p>
          </div>
          <div className="search__answer">
            <div className="search__query" onClick={() => setRoomsPopupVisibility(!roomsPopupVisibility)}>
              <h6> Guests </h6>
              <KeyboardArrowDownIcon />
            </div>
            <p>
              1
              {' '}
              Room,
              {' '}
              {formData.adults}
              {' '}
              {formData.adults === 1 ? 'Adult' : 'Adults'}
              {' '}
              {formData.kids !== 0 && (
                <>
                  &
                  {' '}
                  {formData.kids}
                  {' '}
                  Children
                </>
              )}
            </p>
            <RoomsPopup adults={formData.adults} kids={formData.kids} handleChange={handleChange} roomsPopupVisibility={roomsPopupVisibility} setRoomsPopupVisibility={setRoomsPopupVisibility} />
          </div>
          <button type="button" onClick={handleSubmit} className="searchFilter__searchbtn">Searches</button>
        </div>
      </div>
      <div className="search" style={{ display: location.pathname !== '/property-search' && 'none' }}>
        <div className="search__content">
          <div className="sort__result">
            <div className="sort">
              <p> Sort By  </p>
              <select name="sort" className="sort__options">
                <option name="Popularity">Popularity</option>
                <option name="Price- Low to High">Price- Low to High</option>
                <option name="Price- High to Low">Price- High to Low</option>
                <option name="User Rating - High to Low">User Rating - High to Low</option>
              </select>
            </div>
            <div className="result">
              {/* <p>| Showing 209+ Properties in Goa </p> */}
            </div>
          </div>
          <div className="search__bar">
            <SearchIcon />
            <input placeholder="Search Location or Property" name="location" value={formData.location} onChange={handleLocationChange} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default SearchFiltersHeader;
