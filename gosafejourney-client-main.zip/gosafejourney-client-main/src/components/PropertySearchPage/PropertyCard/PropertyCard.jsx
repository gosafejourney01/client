/* eslint-disable */
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Rating } from '@mui/material';
import StarBorderRoundedIcon from '@mui/icons-material/StarBorderRounded';
import StarRoundedIcon from '@mui/icons-material/StarRounded';
import Auth from '../../Auth/Auth';
// import roomtype1 from '../../../images/roomtype1.png';
// import propertyimg1 from '../../../images/hotelimg_1.png';
// import propertyimg2 from '../../../images/hotelimg_2.png';
// import propertyimg3 from '../../../images/hotelimg_3.png';
import available from '../../../images/available_2.svg';
import notAvailable from '../../../images/cancel_1.svg';
import './PropertyCard.scss';

function PropertyCard({ property, setCurrentProperty, formData }) {
  const [open, setOpen] = useState(false);
  const [viewableImage, setViewableImage] = useState(property?.propertyImages[0]);
  const navigate = useNavigate();
  const handleOpen = (e) => {
    e.cancelBubble = true;
    if (e.stopPropagation) e.stopPropagation();
    setOpen(true);
  };

  const openPropertyDetails = (e) => {
    e.cancelBubble = true;
    setCurrentProperty(property);
    if (e.stopPropagation) e.stopPropagation();
    navigate('/property-details', { state: { formData } });
  };

  const getTax = (val) => {
    const tax = (28 * val) / 100;
    return tax;
  };

  return (
    <div className="propertyCard">
      <div className="propertyCard__content" onClick={openPropertyDetails}>
        <div className="propertyCard__img">
          <img src={viewableImage} alt="property" />
          <div className="propertyCard__bottomImgs">
            <img src={property?.propertyImages[1]} alt="property" onMouseOver={() => setViewableImage(property?.propertyImages[1])} onMouseOut={() => setViewableImage(property?.propertyImages[0])} />
            <img src={property?.propertyImages[2]} alt="property" onMouseOver={() => setViewableImage(property?.propertyImages[2])} onMouseOut={() => setViewableImage(property?.propertyImages[0])} />
            <img src={property?.propertyImages[3]} alt="property" onMouseOver={() => setViewableImage(property?.propertyImages[3])} onMouseOut={() => setViewableImage(property?.propertyImages[0])} />
            <img src={property?.propertyImages[4]} alt="property" onMouseOver={() => setViewableImage(property?.propertyImages[4])} onMouseOut={() => setViewableImage(property?.propertyImages[0])} />
          </div>
        </div>
        <div className="propertyCard__details">
          <div className="propertyCard__desc">
            <div className="propertyCard__rating">
              <span>{property?.rating}</span>
              {/* <p>Excellent</p> */}
              <p className="propertyCard__numRating">
                ({property?.reviews?.length || 0}
                &nbsp;VERIFIED RATINGS)
              </p>
            </div>
            <div className="leaveReviewModal__stars">
              <h3>{property?.propertyName}</h3>
              <Rating
                name="half-rating"
                value={parseInt(property?.rating[0])}
                size="small"
                precision={0.1}
                readOnly
                icon={<StarRoundedIcon fontSize="inherit" />}
                emptyIcon={<StarBorderRoundedIcon fontSize="inherit" />}
              />
            </div>
            <div className="propertyCard__hotelLocation">
              <p>{property?.city}</p>
              {/* <p> | 7-8 minutes walk to Calangute Beach</p> */}
            </div>
            <div className="propertyCard__mobileFeaturesPrice">
              <div className="propertyCard__featuresInclusions">
                <div className="propertyCard__hotelFeatures">
                  {/* <span className="propertyCard__hotelType">RESORT</span> */}
                  {/* <span className="propertyCard__hotelRule">Couple Friendly</span> */}
                </div>
                {property?.isBreakfastProvided ? (
                  <div className="propertyCard__inclusions">
                    <img src={available} alt="included" />
                    <p>Breakfast Included</p>
                  </div>
                ) : (
                  <div className="propertyCard__inclusions">
                    <img src={notAvailable} alt="not included" />
                    <p>Breakfast not Included</p>
                  </div>
                )}
              </div>
              <div className="propertyCard__mobilePrice">
                {/* <s>₹ 10,144</s> */}
                <h3>{`₹ ${property?.price}`}</h3>
                <p>{`+ ₹ ${getTax(property?.price)} taxes & fees`}</p>
                <p>Per Night</p>
                <span>Login to book now</span>
              </div>
            </div>
          </div>
          <div className="propertyCard__divider" />
          <div className="propertyCard__price">
            {/* <s>₹ 10,144</s> */}
            <h3>{`₹ ${property?.price}`}</h3>
            <p>{`+ ₹ ${getTax(property?.price)} taxes & fees`}</p>
            <p>Per Night</p>
            {localStorage.getItem('profile') === undefined && <span onClick={handleOpen}>Login to book now</span>}
          </div>
        </div>
      </div>
      <Auth open={open} setOpen={setOpen} />
    </div>
  );
}

export default PropertyCard;
