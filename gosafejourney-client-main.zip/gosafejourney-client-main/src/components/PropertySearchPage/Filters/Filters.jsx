import React from 'react';
import Checkbox from '@mui/material/Checkbox';
// import PoolIcon from '@mui/icons-material/Pool';
// import NetworkWifiIcon from '@mui/icons-material/NetworkWifi';
// import SpaIcon from '@mui/icons-material/Spa';
import './Filters.scss';

function Filters({ handleFilter }) {
  return (
    <div className="filters">
      <h2>Select Filters </h2>
      <div className="filters__content">
        <div className="price">
          <h3>Price (per night)</h3>
          <div className="price__options">
            <div className="filters__checkbox">
              <div className="filters__checkbox__content">
                <Checkbox name="2000" onClick={handleFilter} unchecked />
                <p>Under  ₹2000</p>
              </div>
              {/* <p>(42)</p> */}
            </div>
            <div className="filters__checkbox">
              <div className="filters__checkbox__content">
                <Checkbox name="3000" onClick={handleFilter} unchecked />
                <p>₹2000 - ₹4000</p>
              </div>
            </div>
            <div className="filters__checkbox">
              <div className="filters__checkbox__content">
                <Checkbox name="5000" onClick={handleFilter} unchecked />
                <p>₹4000 - ₹6000</p>
              </div>
            </div>
            <div className="filters__checkbox">
              <div className="filters__checkbox__content">
                <Checkbox name="6000" onClick={handleFilter} unchecked />
                <p>₹6000 & above</p>
              </div>
            </div>
          </div>
        </div>
        <div className="star__rating">
          <h3>Star Category</h3>
          <div className="filters__checkbox">
            <div className="filters__checkbox__content">
              <Checkbox name="5" onClick={handleFilter} unchecked />
              <p>5 Star</p>
            </div>
            {/* <p>(42)</p> */}
          </div>
          <div className="filters__checkbox">
            <div className="filters__checkbox__content">
              <Checkbox name="4" onClick={handleFilter} unchecked />
              <p>4 Star</p>
            </div>
            {/* <p>(569)</p> */}
          </div>
          <div className="filters__checkbox">
            <div className="filters__checkbox__content">
              <Checkbox name="3" onClick={handleFilter} unchecked />
              <p>3 Star</p>
            </div>
            {/* <p>(412)</p> */}
          </div>
        </div>
        {/* <div className="property__amentities__type">
          <h3>Property Type</h3>
          <div className="filters__checkbox">
            <div className="filters__checkbox__content">
              <Checkbox name="Apartment" unchecked />
              <p>Apartment</p>
            </div> */}
        {/* <p>(569)</p> */}
        {/* </div>
          <div className="filters__checkbox">
            <div className="filters__checkbox__content">
              <Checkbox name="Hotel" unchecked />
              <p>Hotel</p>
            </div> */}
        {/* <p>(569)</p> */}
        {/* </div>
          <div className="filters__checkbox">
            <div className="filters__checkbox__content">
              <Checkbox name="Villa" unchecked />
              <p>Villa</p>
            </div> */}
        {/* <p>(59)</p> */}
        {/* </div> */}
        {/* <div className="more">
            <p>Show More</p>
          </div> */}
        {/* </div> */}
        {/* <div className="property__amentities__type">
          <h3>Amenities</h3>
          <div className="filters__checkbox">
            <div className="filters__checkbox__content">
              <Checkbox name="Swimming Pool" unchecked />
              <p>Swimming Pool</p>
              <PoolIcon />
            </div>
            <p>(569)</p>
          </div>
          <div className="filters__checkbox">
            <div className="filters__checkbox__content">
              <Checkbox name="WIFI" unchecked />
              <p>WIFI</p>
              <NetworkWifiIcon />
            </div>
            <p>(569)</p>
          </div>
          <div className="filters__checkbox">
            <div className="filters__checkbox__content">
              <Checkbox name="Spa" unchecked />
              <p>Spa</p>
              <SpaIcon />
            </div>
            <p>(59)</p>
          </div>
          <div className="more">
            <p>Show More</p>
          </div>
        </div> */}
      </div>
    </div>
  );
}

export default Filters;
