import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Dialog, IconButton } from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import Input from '../Input/Input';
// import googlelogin from '../../images/googlelogin.svg';
import { signin, signup, verify } from '../../actions/auth';
import './Auth.scss';
import { forgotPassword, resetPassword } from '../../api';

function Auth({ open, setOpen }) {
  const initialState = {
    firstName: '', lastName: '', email: '', phone: '', otp: '', password: '', confirmPassword: '',
  };
  const [formData, setFormData] = useState(initialState);
  const [mainAuth, setMainAuth] = useState(true);
  const [isSignUp, setIsSignUp] = useState(false);
  const [isForgotPassword, setForgotPassword] = useState(false);
  const [isResetPassword, setIsResetPassword] = useState(false);
  const [otpVerification, setOtpVerification] = useState(false);
  const [showOtp, setShowOtp] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleShowOtp = () => setShowOtp((prevShowOtp) => !prevShowOtp);

  const handleShowPassword = () => setShowPassword((prevShowPassword) => !prevShowPassword);

  const handleShowConfirmPassword = () => setShowConfirmPassword((prevConfirmShowPassword) => !prevConfirmShowPassword);

  const handleClose = () => {
    setOpen(false);
    setFormData(initialState);
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const goBackToMainAuth = () => {
    setOtpVerification(false);
    setMainAuth(true);
  };

  const mainAuthToOtpVerification = async (e) => {
    e.preventDefault();
    if (isResetPassword) {
      await resetPassword(formData);
      setForgotPassword(false);
      setIsResetPassword(false);
      setIsSignUp(false);
    } else if (isForgotPassword) {
      await forgotPassword(formData);
      setIsResetPassword(true);
    } else if (isSignUp) {
      // setOtpVerification(true);
      dispatch(signup(formData, setOtpVerification, setMainAuth, setLoading));
      // setMainAuth(false);
    } else {
      dispatch(signin(formData, () => { navigate('/'); }, handleClose, setLoading));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(verify(formData, () => { navigate('/'); }, handleClose, setLoading));
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
    >
      <div className="auth">
        {mainAuth && (
          <form className="auth__main" onSubmit={mainAuthToOtpVerification}>
            {isSignUp && (
              <>
                <div className="auth__name">
                  <div>
                    <span>First Name</span>
                    <Input name="firstName" placeholder="First Name" value={formData.firstName} handleChange={handleChange} />
                  </div>
                  <div>
                    <span>Last Name</span>
                    <Input name="lastName" placeholder="Last Name" value={formData.lastName} handleChange={handleChange} />
                  </div>
                </div>
                <div>
                  {/* change input type to phone */}
                  <span>Phone Number</span>
                  <Input name="phone" type="tel" placeholder="XXXXX XXXXX" value={formData.phone} handleChange={handleChange} />
                </div>
              </>
            )}
            <span>Email</span>
            <Input name="email" placeholder="Enter email" value={formData.email} handleChange={handleChange} type="email" />
            {(!isForgotPassword || isResetPassword)
              && (
                <>
                  <span>Password</span>
                  <Input name="password" placeholder="Enter your password" value={formData.password} handleChange={handleChange} type={showPassword ? 'text' : 'password'} handleShowPassword={handleShowPassword} />
                </>
              )}
            {(isSignUp || isResetPassword) && (
              <>
                <span>Confirm Password</span>
                <Input name="confirmPassword" placeholder="Confirm your password" value={formData.confirmPassword} handleChange={handleChange} type={showConfirmPassword ? 'text' : 'password'} handleShowPassword={handleShowConfirmPassword} />
              </>
            )}
            {isResetPassword
              && <Input name="otp" placeholder="Enter OTP" handleChange={handleChange} type={showOtp ? 'text' : 'password'} handleShowPassword={handleShowOtp} />}
            <button type="submit" className="auth__email">{isSignUp ? 'CONTINUE' : isForgotPassword ? isResetPassword ? 'RESET PASSWORD' : 'SEND RESET EMAIL' : (loading ? 'Loading...' : 'LOGIN')}</button>
            {/* <p className="auth__divider">
              Or
              {' '}
              {isSignUp ? 'Signup' : 'Login'}
              {' '}
              With
            </p> */}
            {/* <button type="button" className="auth__google">
              <img src={googlelogin} alt="Login with Google" />
              {isSignUp ? 'Signup' : 'Login'}
              {' '}
              with Google
            </button> */}
            <p>
              by proceeding, you agree to gosafejourney’s
              {' '}
              <span>Privacy Policy, User Agreement</span>
              {' '}
              &
              {' '}
              <span>T&Cs</span>
            </p>
            <center className="auth__switchMode">
              {isSignUp ? (
                <p>
                  Already have an Account?
                  {' '}
                  <span onClick={() => setIsSignUp(false) && setForgotPassword(false) && isResetPassword(false)}>Sign in here</span>
                </p>
              ) : (
                <>
                  <p>
                    Don&apos;t have an Account?
                    {' '}
                    <span onClick={() => setIsSignUp(true) && setForgotPassword(false) && isResetPassword(false)}>Sign up here</span>
                  </p>
                  {!isForgotPassword && (
                    <p>
                      <span onClick={() => setForgotPassword(true) && isResetPassword(false)}>Forgot Password?</span>
                    </p>
                  )}
                </>
              )}
            </center>
          </form>
        )}
        {(otpVerification) && (
          <form className="auth__otp" onSubmit={handleSubmit}>
            <IconButton className="auth__otpGoBack" onClick={goBackToMainAuth}>
              <ArrowBackIcon />
            </IconButton>
            <span>Enter OTP Sent to your EMAIL ADDRESS</span>
            <Input name="otp" placeholder="Enter OTP" handleChange={handleChange} type={showOtp ? 'text' : 'password'} handleShowPassword={handleShowOtp} />
            <button type="submit" disabled={formData.otp.length !== 6} className="auth__email">VERIFY</button>
          </form>
        )}
      </div>
    </Dialog>
  );
}

export default Auth;
