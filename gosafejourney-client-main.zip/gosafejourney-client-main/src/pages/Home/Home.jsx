import React from 'react';
import PropertySearch from '../../components/HomePage/PropertySearch/PropertySearch';
// import Offers from '../../components/HomePage/Offers/Offers';
import TopDestinations from '../../components/HomePage/TopDestinations/TopDestinations';
// import PropertyTypes from '../../components/HomePage/PropertyTypes/PropertyTypes';
import WhyUs from '../../components/HomePage/WhyUs/WhyUs';
import Testimonials from '../../components/HomePage/Testimonials/Testimonials';

function Home({
  formData, setFormData, handleChange, handleCheckInCheckOutChange, handleStayTypeChange,
}) {
  return (
    <div className="home">
      <PropertySearch formData={formData} setFormData={setFormData} handleChange={handleChange} handleCheckInCheckOutChange={handleCheckInCheckOutChange} handleStayTypeChange={handleStayTypeChange} />
      {/* <Offers /> */}
      <TopDestinations formData={formData} setFormData={setFormData} />
      {/* <PropertyTypes /> */}
      <WhyUs />
      <Testimonials />
    </div>
  );
}

export default Home;
