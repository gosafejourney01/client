import React from 'react';
/* import { Link } from 'react-router-dom';
import ChevronRightIcon from '@mui/icons-material/ChevronRight'; */
import SideProfile from '../../components/ProfilePage/SideProfile/SideProfile';
import ProfileDetailsRight from '../../components/ProfilePage/ProfileDetailsRight/ProfileDetailsRight';
import './Profile.scss';

function ProfileDetails() {
  const profile = JSON.parse(localStorage.getItem('profile'));
  if (!profile) {
    window.location.href = '/';
  }

  return (
    <div className="ProfileDetails">
      <div className="ProfileDetails__content">
        <div className="ProfileDetails__contenthead">
          <div className="ProfileDetails__route">
            {/* <Link to="/profile"><p>My Accounts</p></Link>
            <ChevronRightIcon />
            <Link to="/profile"><p>My Profile</p></Link> */}
            <p>My Profile</p>
          </div>
        </div>
        <div className="ProfileDetails__mainContent">
          <div className="ProfileDetails__profilebox">
            <SideProfile />
          </div>
          <ProfileDetailsRight />
        </div>
      </div>
    </div>
  );
}

export default ProfileDetails;
