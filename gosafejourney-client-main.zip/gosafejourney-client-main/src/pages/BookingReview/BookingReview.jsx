/* eslint-disable */
import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
// import { Download } from '@mui/icons-material';
import BookingGuestDetails from '../../components/BookingReviewPage/BookingGuestDetails/BookingGuestDetails';
import BookingReviewSummary from '../../components/BookingReviewPage/BookingReviewSummary/BookingReviewSummary';
import PriceBreakup from '../../components/PriceBreakup/PriceBreakup';
// import CouponCode from '../../components/BookingReviewPage/CouponCode/CouponCode';
import './BookingReview.scss';

function BookingReview() {
  const location = useLocation();
  const initialState = {
    salutation: 'Mr.', firstName: '', lastName: '', email: '', phone: '', gst: false, registrationNo: '', company: '', companyAddress: '',
  };
  // console.log(location.state.formData);
  const [formData, setFormData] = useState(initialState);
  const [names, setNames] = useState([]);
  const [night, setNight] = useState(0);
  const  [date1, setDate1] = useState() ;
  const [date2, setDate2] = useState() ;
  const [bill,setBill] = useState({});

   const handleChange = (e) => {
     if (typeof (e) !== 'string') {
       setFormData({ ...formData, [e.target.name]: e.target.value });
     } else {
       setFormData({ ...formData, phone: e });
     }
   };
  const generateBill = (data) =>{
    setBill(data);
  } 
  useEffect(() => {
    const date1 = new Date(location.state.formData?.checkInDate);
    const date2 = new Date(location.state.formData?.checkOutDate);
    const diff = Math.abs(date2.getTime() - date1.getTime());
    const noofdays = Math.ceil(diff / (1000 * 3600 * 24));
    setDate1(date1);
    setDate2(date2);
    setNight(noofdays);
    // eslint-disable-next-line
  }, [])

  // const handleSubmit = (e) => {
  //   e.preventDefault();
  //   console.log(formData);
  // };
  return (
    <div className="bookingReview">
      <div className="bookingReview__banner" />
      <div className="bookingReview__content">
        <div className="bookingDetails__contenthead">
          <h2 className="bookingReview__head">Review Your Booking</h2>
          {/* <div className="bookingDetails__downloadReceipt">
            <Download />
            <p>Download Receipt </p>
          </div> */}
        </div>
        <div className="bookingReview__mainContent">
          <div className="bookingReview__contentSummary">
            <BookingReviewSummary currentProperty={location.state.currentProperty} formData={location.state.formData} bill={bill} price={location.state.room?.price*night} room={location.state.room} night={night} />
            <BookingGuestDetails handleChange={handleChange} formData={formData} setFormData={setFormData} names={names} setNames={setNames} />
            {/* <div className="bookingReview__agreement">
              <div className="bookingReview__agreement__firstline">
                <p>By proceeding, I agree to GoSafeJourney</p>
                <h6>User Agreement, Terms of Service </h6>
              </div>
              <h6>and Cancellation & Property Booking Policies.</h6>
            </div>
            <button type="button" className="bookingReview__paybtn" onClick={handleSubmit}>PAY NOW</button> */}
          </div>
          <div className="bookingReview__contentPrice">
            <PriceBreakup amount={location.state.room?.price*night} room={location.state.room} generateBill={generateBill} night={night} date1={date1} date2={date2} formData={formData} names={names} />
            {/* <CouponCode /> */}
          </div>
        </div>
      </div>
    </div>
  );
}

export default BookingReview;
