import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import SearchFiltersHeader from '../../components/SearchFiltersHeader/SearchFiltersHeader';
import PropertyCard from '../../components/PropertySearchPage/PropertyCard/PropertyCard';
import Filters from '../../components/PropertySearchPage/Filters/Filters';
import './PropertySearch.scss';
import SearchFilterHeaderMobile from '../../components/SearchFilterHeaderMobile/SearchFilterHeaderMobile';

function PropertySearch({
  formData,
  setCurrentProperty,
  setFormData,
  handleChange,
  handleCheckInCheckOutChange,
  handlePricingChange,
}) {
  const allProperties = useSelector((state) => state.property.propertyData);
  const [filterArray, setFilterArray] = useState([]);
  const [properties, setProperties] = useState();

  useEffect(() => {
    setProperties(allProperties);
  }, [allProperties]);

  const handleSubmit = (e) => {
    e.preventDefault();
    document.getElementById(
      'searchFilterHeaderMobile__searchresults',
    ).style.display = 'flex';
    document.getElementById('searchFilterHeaderMobile__edit').style.display = 'none';
  };

  const handleFilter = (event) => {
    const val = event.target.name;
    if (filterArray.includes(val)) {
      const temp = filterArray.filter((item) => item !== val);
      setFilterArray(temp);
    } else {
      const temp = [...filterArray, val];
      setFilterArray(temp);
    }
  };

  const getPrice = (p) => {
    let val = 0;
    if (p < 2000) val = 2000;
    else if (p >= 2000 && p <= 4000) val = 3000;
    else if (p >= 4000 && p <= 6000) val = 5000;
    else val = 6000;
    return val.toString();
  };
  useEffect(() => {
    const len = filterArray.length;
    if (len < 1) {
      setProperties(allProperties);
    } else {
      const temp = allProperties?.filter((property) => filterArray.includes(property.rating.charAt(0)) || filterArray.includes(getPrice(property.price)));
      setProperties(temp);
    }
  }, [filterArray]);

  return (
    <div className="propertysearchpage">
      <SearchFiltersHeader
        formData={formData}
        setFormData={setFormData}
        handleChange={handleChange}
        handleCheckInCheckOutChange={handleCheckInCheckOutChange}
        // handleSubmit={handleSubmit}
      />
      <SearchFilterHeaderMobile
        formData={formData}
        handleChange={handleChange}
        handleCheckInCheckOutChange={handleCheckInCheckOutChange}
        handleSubmit={handleSubmit}
        handlePricingChange={handlePricingChange}
        setFormData={setFormData}
      />
      <div className="propertysearch__content">
        <div className="propertysearch__mainContent">
          <div className="propertysearch__filter">
            <Filters handleFilter={handleFilter} />
          </div>
          <div className="propertysearch__page__results">
            <h2>
              {formData.location !== undefined
              && formData.location !== ''
              && formData.location !== null
                ? `Showing Properties in ${formData.location}`
                : 'Search Popular Properties'}
            </h2>
            <div className="propertysearchPage__propertyCards">
              {!properties ? (
                <>Loading</>
              ) : (
                properties.map((property, index) => (
                  <PropertyCard
                    formData={formData}
                    property={property}
                    setCurrentProperty={setCurrentProperty}
                    key={index}
                  />
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default PropertySearch;
