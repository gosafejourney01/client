/* eslint-disable no-underscore-dangle */
import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import { /* Download, */ EditOutlined, CloseOutlined } from '@mui/icons-material';
import { useDispatch, useSelector } from 'react-redux';
import axios from 'axios';
import BookingSummary from '../../components/BookingDetailsPage/BookingSummary/BookingSummary';
import PriceBreakup from '../../components/PriceBreakup/PriceBreakup';
import LeaveReviewModal from '../../components/LeaveReviewModal/LeaveReviewModal';
import CancelbookingModal from '../../components/CancelBookingModal/CancelBookingModal';
import './BookingDetails.scss';
import { cancelBooking } from '../../actions/booking';

function BookingDetails() {
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const [cancelOpen, setCancelOpen] = useState(false);
  const handleCancelOpen = () => setCancelOpen(true);
  const bookingData = useSelector((state) => state.booking.bookingData);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const generateBill = (data) => {
    console.log(data);
  };

  console.log('booking data', bookingData, process.env.REACT_APP_RAZORPAY_KEY_ID);
  const handleCancellation = async () => {
    // eslint-disable-next-line no-underscore-dangle
    const currentDate = Date.now();
    const checkInDate = Date.parse(bookingData.checkInDate);
    const validCancellatinDays = bookingData.roomId.propertyId.cancellationDays;
    const paymentIdString = bookingData.paymentId;
    const amountToRefund = bookingData.amount;
    let cancelBookingData = {
      roomId: bookingData.roomId._id,
      noOfBookedRooms: bookingData.noBookedRooms,
      bookingStatus: 'Cancelled',
      guestData: bookingData.guestData,
      clientId: bookingData.clientId,
    };
    if (Math.abs(checkInDate - currentDate) / (24 * 60 * 60 * 1000) > validCancellatinDays) {
      cancelBookingData = { ...cancelBookingData, refundStatus: 'refund processing' };
      dispatch(cancelBooking(bookingData._id, cancelBookingData, () => { navigate('/mybooking'); }));
      const response = await axios.post(
        `https://api.razorpay.com/v1/payments/${paymentIdString}/refund`,
        {
          amount: amountToRefund,
        },
        {
          auth: {
            username: process.env.REACT_APP_RAZORPAY_KEY_ID,
            password: process.env.REACT_APP_RAZORPAY_KEY,
          },
        },
      );
      console.log('payment response', response);
      alert('refund processing started Check your status after 5-7 bussiness Days');
    } else {
      cancelBookingData = { ...cancelBookingData, refundStatus: 'refund is not eligible' };
      dispatch(cancelBooking(bookingData._id, cancelBookingData, () => { navigate('/mybooking'); }));
    }
    setCancelOpen(false);
  };

  useEffect(() => {
    if (Object.keys(bookingData).length === 0) {
      navigate('/mybooking');
    }
  }, []);

  return (
    <div className="bookingDetails">
      {bookingData.roomId && (
        <>
          <div className="bookingDetails__banner" />
          <div className="bookingDetails__content">
            <div className="bookingDetails__contenthead">
              <div className="bookingDetails__route">
                <Link to="/profile"><p>My Account</p></Link>
                <ChevronRightIcon />
                <Link to="/mybooking"><p>Bookings</p></Link>
                <ChevronRightIcon />
                <p>{bookingData?.roomId?.propertyId?.propertyName}</p>
              </div>
              {(bookingData.bookingStatus.toLowerCase() === 'completed' || bookingData.bookingStatus.toLowerCase() === 'active') && (
                <div className="bookingDetails__downloadReceipt">
                  {/* <Download />
              <p>Download Receipt </p> */}
                  <p> Booking receipt has been sent to your email </p>
                </div>
              )}
            </div>
            <div className="bookingDetails__mainContent">
              <BookingSummary bookingData={bookingData} />
              <div className="bookingDetails__contentPrice">
                <PriceBreakup amount={bookingData.amount} room={bookingData.roomId} generateBill={generateBill} night={new Date(bookingData.checkOutDate).getDay() - new Date(bookingData.checkInDate).getDay()} date1={bookingData.checkInDate} date2={bookingData.checkOutDate} bookingStatus={bookingData.bookingStatus.toLowerCase()} />
                {bookingData.bookingStatus.toLowerCase() === 'completed' && !bookingData.reviewed && (
                  <div className="bookingDetails__contentReview" onClick={handleOpen}>
                    <EditOutlined />
                    <p>Leave a Review</p>
                  </div>
                )}
                {bookingData.bookingStatus.toLowerCase() === 'active' && (
                  <div className="bookingDetails__contentCancel" onClick={handleCancelOpen}>
                    <CloseOutlined />
                    <p>Cancel Booking</p>
                  </div>
                )}
              </div>
            </div>
          </div>
          <LeaveReviewModal open={open} setOpen={setOpen} bookingId={bookingData._id} />
          <CancelbookingModal open={cancelOpen} setOpen={setCancelOpen} propertyName={bookingData?.roomId?.propertyId?.propertyName} handleCancellation={handleCancellation} />
        </>
      )}
    </div>
  );
}

export default BookingDetails;
