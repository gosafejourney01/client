import React from 'react';
import { Link } from 'react-router-dom';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import BookingStatusSection from '../../components/MyBookingsPage/BookingStatusSection/BookingStatusSection';
import './MyBookings.scss';

function MyBookings() {
  return (
    <div className="myBookings">
      <div className="myBookings__banner" />
      <div className="myBookings__content">
        <div className="myBookings__contenthead">
          <div className="myBookings__route">
            <Link to="/profile"><p>My Account</p></Link>
            <ChevronRightIcon />
            <p>Bookings</p>
          </div>
        </div>
        <BookingStatusSection />
      </div>
    </div>
  );
}

export default MyBookings;
