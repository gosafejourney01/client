import React from 'react';
import { useDispatch } from 'react-redux';
import { Link, useLocation } from 'react-router-dom';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
// import PropertyAmenities from '../../components/PropertyDetailsPage/PropertyAmenities/PropertyAmenities';
import PropertyBanner from '../../components/PropertyDetailsPage/PropertyBanner/PropertyBanner';
import PropertyDetailsNavbar from '../../components/PropertyDetailsPage/PropertyDetailsNavbar/PropertyDetailsNavbar';
import PropertyLocation from '../../components/PropertyDetailsPage/PropertyLocation/PropertyLocation';
import PropertyOverview from '../../components/PropertyDetailsPage/PropertyOverview/PropertyOverview';
import PropertyReviews from '../../components/PropertyDetailsPage/PropertyReviews/PropertyReviews';
import PropertyRooms from '../../components/PropertyDetailsPage/PropertyRooms/PropertyRooms';
// import PropertyRules from '../../components/PropertyDetailsPage/PropertyRules/PropertyRules';
import PropertyRoomsMobile from '../../components/PropertyDetailsPage/PropertyRoomsMobile/PropertyRoomsMobile';
import SearchFiltersHeader from '../../components/SearchFiltersHeader/SearchFiltersHeader';
import SearchFilterHeaderMobile from '../../components/SearchFilterHeaderMobile/SearchFilterHeaderMobile';
import './PropertyDetails.scss';
import getProperties from '../../actions/property';

function PropertyDetails({
  formData, currentProperty, setFormData, handleChange, handleCheckInCheckOutChange, handlePricingChange,
}) {
  const location = useLocation();
  const dispatch = useDispatch();

  const handleSubmit = (e) => {
    console.log('formData');
    e.preventDefault();
    dispatch(getProperties(formData));
  };

  return (
    <div className="hotelDetails">
      <SearchFiltersHeader formData={formData} handleChange={handleChange} handleCheckInCheckOutChange={handleCheckInCheckOutChange} handleSubmit={handleSubmit} />
      <SearchFilterHeaderMobile formData={formData} handleChange={handleChange} handleCheckInCheckOutChange={handleCheckInCheckOutChange} handleSubmit={handleSubmit} handlePricingChange={handlePricingChange} setFormData={setFormData} />
      <div className="hotelDetails__content">
        <div className="hotelDetails__route">
          <Link to="/"><p>Home</p></Link>
          <ChevronRightIcon />
          <Link to="/property-search"><p>Hotels and more in Goa</p></Link>
          <ChevronRightIcon />
          <p>{currentProperty?.propertyName}</p>
        </div>
        <PropertyBanner currentProperty={currentProperty} />
        <PropertyDetailsNavbar />
        <PropertyOverview currentProperty={currentProperty} />
        <PropertyRooms currentPropertyRoom={currentProperty?.rooms} currentProperty={currentProperty} formData={location.state.formData} />
        <PropertyRoomsMobile />
        <PropertyLocation />
        {/* <PropertyAmenities />
        <PropertyRules /> */}
        <PropertyReviews reviews={currentProperty?.reviews} />
      </div>
    </div>
  );
}

export default PropertyDetails;
