import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { toast, Toaster } from 'react-hot-toast';
import './ResetPassword.scss';
import { update } from '../../actions/auth';

function ResetPassword() {
  const [changePasswordData, setChangePasswordData] = useState({
    currPassword: '',
    newPassword: '',
    confirmNewPassword: '',
  });

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleChange = (e) => {
    setChangePasswordData({ ...changePasswordData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (changePasswordData.newPassword === changePasswordData.confirmNewPassword) {
        console.log(changePasswordData);
        const profile = localStorage.getItem('profile');
        const { result } = JSON.parse(profile);
        const { _id } = result;
        dispatch(update(_id, profile));
      } else {
        toast.error('Passwords do not match.');
      }
    } catch (error) {
      console.log(error);
      toast.error('Current password is incorrect.');
    }
  };

  const goBackToDashboard = () => {
    navigate('/');
  };

  return (
    <div className="resetPassword">
      <form onSubmit={handleSubmit} className="resetPassword__content">
        <h3>Change Password</h3>
        <div className="resetPassword__card">
          <h4>
            Current password
            <span>*</span>
          </h4>
          <input name="currPassword" type="password" value={changePasswordData.currPassword} required onChange={handleChange} />
          <h4>
            New password
            <span>*</span>
          </h4>
          <input name="newPassword" type="password" value={changePasswordData.newPassword} required onChange={handleChange} />
          <h4>
            Confirm password
            <span>*</span>
          </h4>
          <input name="confirmNewPassword" type="password" value={changePasswordData.confirmNewPassword} required onChange={handleChange} />
        </div>
        <button className="resetPassword__continue" type="submit">Change Password</button>
        <button className="resetPassword__goback" type="button" onClick={goBackToDashboard}>No. Go back.</button>
      </form>
      <Toaster />
    </div>
  );
}

export default ResetPassword;
