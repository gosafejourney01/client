import * as api from '../api';
import {
  START_LOADING, END_LOADING, FETCH_ROOMS,
} from '../constants/actionTypes';

const getRooms = (roomIds) => async (dispatch) => {
  try {
    dispatch({ type: START_LOADING });
    const { data } = await api.fetchRooms(roomIds);
    dispatch({ type: FETCH_ROOMS, payload: data });
    dispatch({ type: END_LOADING });
  } catch (error) {
    console.log(error);
  }
};

export default getRooms;
