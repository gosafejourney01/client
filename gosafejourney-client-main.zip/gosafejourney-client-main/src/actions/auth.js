import { toast } from 'react-hot-toast';
import { AUTH, UPDATE_AUTH } from '../constants/actionTypes';
import * as api from '../api';

export const signin = (formData, navigate, handleClose, setLoading) => async (dispatch) => {
  try {
    setLoading(true);
    const { data } = await api.signIn(formData);
    dispatch({ type: AUTH, data });
    handleClose();
    setLoading(false);
    if (navigate) navigate();
  } catch (error) {
    toast.error('Invalid Credentials');
    console.log(error);
    setLoading(false);
  }
};

export const forgotPassword = async (formData) => {
  try {
    const { data } = await api.forgotPassword(formData);
    return data;
  } catch (error) {
    toast.error('Invalid Credentials');
    console.log(error);
    return error;
  }
};

export const resetPassword = async (formData) => {
  try {
    const { data } = await api.resetPassword(formData);
    return data;
  } catch (error) {
    toast.error('Invalid Credentials');
    console.log(error);
    return error;
  }
};

export const signup = (formData, setOtpVerification, setMainAuth, setLoading) => async (dispatch) => {
  try {
    setLoading(true);
    const { data } = await api.signUp(formData);
    dispatch({ type: AUTH, data });
    setOtpVerification(true);
    setMainAuth(false);
    setLoading(false);
  } catch (error) {
    toast.error('Password do not match');
    console.log(error);
    setLoading(false);
  }
};

export const verify = (formData, navigate, handleClose, setLoading) => async (dispatch) => {
  try {
    setLoading(true);
    const { data } = await api.verify(formData);
    dispatch({ type: AUTH, data });
    handleClose();
    if (navigate) navigate();
    setLoading(false);
  } catch (error) {
    toast.error('Invalid/Expired OTP');
    console.log(error);
    setLoading(false);
  }
};

export const loadUser = (id, navigate) => async (dispatch) => {
  try {
    const { data } = await api.getUser(id);
    dispatch({ type: AUTH, data });
    if (navigate) navigate();
  } catch (error) {
    toast.error('Failed to load profile. Please login again.');
    console.log(error);
  }
};

export const update = (id, formData, navigate) => async (dispatch) => {
  try {
    const { data } = await api.updateUser(id, formData);
    dispatch({ type: UPDATE_AUTH, data });
    if (navigate) navigate();
  } catch (error) {
    toast.error('Failed to update profile. Please try again.');
    console.log(error);
  }
};
