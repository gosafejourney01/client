import { toast } from 'react-hot-toast';
import * as api from '../api';
import {
  START_LOADING, END_LOADING, FETCH_BOOKINGS, FETCH_BOOKING, CANCEL_BOOKING,
} from '../constants/actionTypes';

export const getBookings = (userId, navigate) => async (dispatch) => {
  try {
    dispatch({ type: START_LOADING });
    const { data } = await api.fetchBookings(userId);
    dispatch({ type: FETCH_BOOKINGS, payload: data });
    dispatch({ type: END_LOADING });
    if (navigate) {
      navigate();
    }
  } catch (error) {
    console.log(error);
  }
};

export const getBooking = (bookingId, navigate, toastMsg) => async (dispatch) => {
  try {
    dispatch({ type: START_LOADING });
    const { data } = await api.fetchBooking(bookingId);
    dispatch({ type: FETCH_BOOKING, payload: data });
    dispatch({ type: END_LOADING });
    if (navigate) {
      navigate();
    }
    if (toastMsg) {
      toast.success(toastMsg);
    }
  } catch (error) {
    console.log(error);
  }
};

export const cancelBooking = (bookingId, cancelBookingData, navigate) => async (dispatch) => {
  try {
    dispatch({ type: START_LOADING });
    const { data } = await api.cancelBooking(bookingId, cancelBookingData);
    console.log(data);
    dispatch({ type: CANCEL_BOOKING, payload: data });
    dispatch({ type: END_LOADING });
    if (navigate) {
      navigate();
    }
  } catch (error) {
    console.log(error);
  }
};

export const addReview = (bookingId, formData, navigate) => async (dispatch) => {
  console.log(bookingId, formData);
  try {
    dispatch({ type: START_LOADING });
    const { data } = await api.addReview(bookingId, formData);
    console.log(data);
    /* dispatch({ type: FETCH_BOOKING, payload: data }); */
    dispatch({ type: END_LOADING });
    if (navigate) {
      navigate();
    }
  } catch (error) {
    console.log(error);
  }
};
