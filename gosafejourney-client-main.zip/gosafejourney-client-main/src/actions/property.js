import * as api from '../api';
import {
  START_LOADING, END_LOADING, FETCH_PROPERTIES,
} from '../constants/actionTypes';

const getProperties = (searchData, navigate) => async (dispatch) => {
  try {
    console.log(searchData);
    dispatch({ type: START_LOADING });
    const { data } = await api.fetchProperties(searchData);
    dispatch({ type: FETCH_PROPERTIES, payload: data });
    dispatch({ type: END_LOADING });
    if (navigate) navigate();
  } catch (error) {
    console.log(error);
  }
};

export default getProperties;
