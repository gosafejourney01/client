import axios from 'axios';

const API = axios.create({ baseURL: process.env.REACT_APP_SERVER_URL });

API.interceptors.request.use((req) => {
  if (localStorage.getItem('profile')) {
    req.headers.Authorization = `Bearer ${JSON.parse(localStorage.getItem('profile')).token}`;
  }
  return req;
});

// Auth
export const signIn = (formData) => API.post('/user/signin', formData);
export const forgotPassword = (formData) => API.post('/user/forgot-password', formData);
export const resetPassword = (formData) => API.post('/user/reset-password', formData);
export const signUp = (formData) => API.post('/user/signup', formData);
export const updateUser = (userId, formData) => API.patch(`/user/${userId}`, { ...formData });
export const verify = (formData) => API.post('/user/verify', formData);
export const getUser = (userId) => API.get(`/user/${userId}`);

// Properties
export const fetchProperties = (searchData) => API.get('/properties/search', { params: searchData });

// Rooms
export const fetchRooms = (formData) => API.post('/rooms/get', formData);

// Payment
export const createPayment = (formData) => API.post('/payment', formData);

// Booking
export const createBooking = (formData) => API.post('/property-bookings', formData);
export const cancelBooking = (bookingId, formData) => API.patch(`/property-bookings/${bookingId}`, { ...formData });

// Bookings
export const fetchBookings = () => API.get('/property-bookings');
export const fetchBooking = (bookingId) => API.get(`/property-bookings/${bookingId}`);

// Reviews
export const addReview = (bookingId, formData) => API.post(`/property-bookings/reviews/${bookingId}`, { ...formData });
